package com.techshare.launcher.views;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.view.*;
import android.content.Context;
import android.view.View.*;
import android.widget.*;
import com.techshare.launcher.views.*;
import com.techshare.launcher.R;
import android.graphics.Color;
import android.widget.SearchView.*;
import com.techshare.launcher.Sqlite;
import android.graphics.Typeface;
import android.view.View.OnClickListener;
import com.easyandroidanimations.library.*;
import java.security.*;
import com.techshare.launcher.Controler;
public class InstructView extends Service {

	private WindowManager windowManager;
	private actionBtn instructparent;

	private ImageView main;
	private LinearLayout container;
	private int id;
	WindowManager.LayoutParams params;

	@Override
	public void onCreate() {
		super.onCreate();

		}



	@Override
	public void onDestroy() {
		super.onDestroy();
		if (instructparent!= null)
			windowManager.removeView(instructparent);
	}

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public int onStartCommand (Intent intent,
							   int flags, int startId){
		String Ide = intent.getStringExtra
		("id");
		
		windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

		id=Sqlite.inTise(Ide);
		switch(Sqlite.inTise(Ide)){
				
			case 0:
				instructparent=new actionBtn(getApplicationContext(),"Drag the left edge to the right to explore more of the launcher settings",R.drawable.slide);
				break;
			case 1:
				instructparent=new actionBtn(getApplicationContext(),"To enable draging of icons, toggle the padlock it will also lock the side menus \n ->NB REMEMBER THIS PADLOCK ONCE YOU CANT ACCESS APPS",R.drawable.close);
				break;
			case 2:
				instructparent=new actionBtn(getApplicationContext(),"To move an app from apps homescreen to another, drag it to the extreme margin",R.drawable.slide);
				break;
				
			case 3:
				instructparent=new actionBtn(getApplicationContext(),"Tap a view to move it to the top, drag a view to any location of desire",R.drawable.slide);
				break;
			case 4:
				instructparent=new actionBtn(getApplicationContext(),"1.The bottom menu gives plenty useful functionalites \n 2.Double tap an app to open an app directly",R.drawable.slide);
				break;
			case 5:
				instructparent=new actionBtn(getApplicationContext(),"1.Click on the eye to either hide or display a view at hacks screen \n 2.Raise a view z index by using the up arrow \n 3.To avoid lagging dont use all views at once",R.drawable.show);
				break;
			case 6:
				instructparent=new actionBtn(getApplicationContext(),"1.Click on the user icon to acess more settings",R.drawable.user);
				break;
				
				
		}

		
		


		params= new WindowManager.LayoutParams(
			WindowManager.LayoutParams.FILL_PARENT,
			WindowManager.LayoutParams.FILL_PARENT,
			WindowManager.LayoutParams.TYPE_PHONE,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
			PixelFormat.TRANSLUCENT);

		params.gravity = Gravity.TOP | Gravity.LEFT;
		params.x = 0;
		params.y = 100;


		windowManager.addView(instructparent,params);
		
		
		return START_STICKY;
	}
	

	private class Movie implements OnTouchListener{
		private int initialX;
		private int initialY;
		private float initialTouchX;
		private float initialTouchY;

		@Override
		public boolean onTouch(View v, MotionEvent event) {
			switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:
					initialX = params.x;
					initialY = params.y;
					initialTouchX = event.getRawX();
					initialTouchY = event.getRawY();
					return true;
				case MotionEvent.ACTION_UP:


					return true;
				case MotionEvent.ACTION_MOVE:


					params.x = initialX
						+ (int) (event.getRawX() - initialTouchX);
					params.y = initialY
						+ (int) (event.getRawY() - initialTouchY);
					windowManager.updateViewLayout(instructparent, params);
					return true;
			}
			return false;
		}

	}


	//This is the custim view kimoda that ill add
	private class actionBtn extends LinearLayout{

		public actionBtn(Context context,String text,int d){
			super(context);

			WindowManager windowManager = (WindowManager)
				context
				.getSystemService(Context.WINDOW_SERVICE);

			int width=windowManager.getDefaultDisplay()
				.getWidth();
			int height=windowManager.getDefaultDisplay()
				.getHeight();

			final float inPixels= context.getResources
			().getDimension(R.dimen.intro_height);
			
			final float inPixiels= context.getResources
			().getDimension(R.dimen.txt_height);
			
			LinearLayout.LayoutParams mpar = new
				LinearLayout.LayoutParams(width,height);
			mpar.setMargins(5,5,0,0);

			ImageView g=new ImageView(context);
			LinearLayout.LayoutParams gpar = new
				LinearLayout.LayoutParams((int)inPixels,(int)inPixels);
			g.setLayoutParams(gpar);
			g.setImageResource(d);
			//new HighlightAnimation(g).animate();
			
			Typeface b = Typeface.createFromAsset(getApplicationContext().getAssets(),"fonts/Walkway_Bold.ttf");
			TextView t=new TextView(context);
			LinearLayout.LayoutParams tpar = new
				LinearLayout.LayoutParams((int)inPixiels,LinearLayout.LayoutParams.WRAP_CONTENT);
			t.setLayoutParams(tpar);
			t.setTypeface(b);
			t.setText("Hey: "+text);
			t.setTextColor(Color.BLACK);
			t.setTextSize(18);
			t.setPadding(50,10,40,50);
			t.setBackgroundResource(R.drawable.rounder);

			
			Button bt=new Button(context);
			LinearLayout.LayoutParams btpar = new
				LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT);
			btpar.setMargins(4,30,4,5);
				bt.setLayoutParams(btpar);
			bt.setText("Got It");
			bt.setBackgroundResource(R.drawable.rounder);
			bt.setOnClickListener(new OnClickListener(){
					@Override
					public void onClick(View b){
						Controler.ofsetBoolean(getApplicationContext(),id);
						stopService(new Intent(getApplication(), InstructView.class));
					}

				});

				
			this.setWeightSum(1);
			this.setGravity(Gravity.CENTER);
			this.setOrientation(LinearLayout.VERTICAL);
			this.addView(g);
			this.addView(t);
			this.addView(bt);
			this.setBackgroundColor(Color.parseColor("#89000000"));
			this.setLayoutParams(mpar);
		}

	}

}
