package com.techshare.launcher.fragments;

import android.app.Activity;
import android.os.*;
import android.view.*;
import android.database.*;
import android.database.sqlite.*;
import android.content.Context;
import java.util.*;
import android.widget.ArrayAdapter;
import android.widget.*;
import android.view.View.*;
import com.techshare.launcher.utils.ArrayUtils;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import com.techshare.launcher.Sqlite;
import com.techshare.launcher.R;
import com.techshare.launcher.Controler;
import com.techshare.launcher.views.ButtonWithIcons;
import android.graphics.*;
import android.preference.*;
import android.content.*;
import com.techshare.launcher.views.InstructView;
import com.techshare.launcher.utils.ImageUtils;
public class ConfigureHacks extends Fragment
{
	private ListView ha;
	private BookMarksAdapter f;
	private ArrayList<Hacks> hackviews;
	private View view;
	private Typeface b,n;
	 @Override
public View onCreateView(LayoutInflater inflater ,
ViewGroup container ,
Bundle savedInstanceState ) {
	String strtext = getArguments().getString("web");
	

   view =inflater .inflate( R.layout .configure_hacks_fragment,
		container, false);
		
		 b = Typeface.createFromAsset(getActivity().getApplicationContext().getAssets(),"Bloodthirsty.ttf");	
		 n = Typeface.createFromAsset(getActivity().getApplicationContext().getAssets(),"fonts/Walkway_Bold.ttf");
		TextView fff=(TextView)view.findViewById(R.id.configurehacksfragmentTextView1);
		
		fff.setTypeface(b);
		
		
		ButtonWithIcons g=(ButtonWithIcons)view.findViewById(R.id.fwd);
		g.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				ConfigureHome webfrag = new ConfigureHome();
				Bundle bundle = new Bundle();
				bundle.putString("web", "web");
				webfrag.setArguments(bundle);
				FragmentTransaction ft = getActivity().getSupportFragmentManager()
					.beginTransaction();
				ft.setCustomAnimations(R.anim.slideleft,
									   R.anim.slideright);
				ft.replace(R.id.configure_appFrameLayout, webfrag,"fragment");
				// Start the animated transition.
				ft.commit();
				
			}
		});
	configure();
	if(strtext==null){
		RelativeLayout ghi=(RelativeLayout)view.findViewById(R.id.bottom);
		ghi.setVisibility(View.GONE);
	}
	
	
	if(Controler.hacksHelpShown(getActivity().getApplicationContext())){
		Intent si=new Intent(getActivity().getApplication(), InstructView.class);
		si.putExtra("id","5");
		getActivity().startService(si);
		}
	
return view;
}
	
	
	public void configure(){
	//Load all hackviews from the database
	hackviews=new ArrayList<Hacks>();
	String dbName = "makindu";
	String tableViews="views";
	SQLiteDatabase myDb = null;
	try{
		myDb =  getActivity().getApplicationContext().openOrCreateDatabase(dbName,Context. MODE_PRIVATE, null);
		Cursor c = myDb.rawQuery("SELECT * FROM "+tableViews+" ORDER BY id asc", null);
		if (c != null ) {
			if  (c.moveToFirst()) {
				do {
					Hacks h=new Hacks();
					int id = c.getInt(c.getColumnIndex("id"));
					String tag = c.getString(c.getColumnIndex("tag"));
					String xcor = c.getString(c.getColumnIndex("xcor"));
					String ycor= c.getString(c.getColumnIndex("ycor"));
					String state = c.getString(c.getColumnIndex("state"));
					h.id=id;
					h.tag=tag;
					h.xcor=xcor;
					h.state=state;
					h.ycor=ycor;
					hackviews.add(h);
				}while (c.moveToNext()); //Move to next row
			}}
	}catch (SQLiteException se ) {Sqlite.report("Couldnt Load views data",getActivity().getApplicationContext());} finally {}

	//set an adapter for grid view
	ha=(ListView)view.findViewById(R.id.hacks_grid);
		f=new BookMarksAdapter(getActivity().getApplicationContext(),hackviews);
	ha.setAdapter(f);

	}




	//this clas is a structure model
	private class Hacks{
		private String tag;	
		private String xcor;
		private String ycor;
		private int id;
		private String state;
	}


	private class BookMarksAdapter extends ArrayAdapter<String> {
		private final Context context;
		private final ArrayList<Hacks> values;
		public BookMarksAdapter(Context context, ArrayList<Hacks>
								values) {
			super (context, R.layout.bookmarks_row, values);
			this .context = context;
			this .values = values;
		}
		@Override
		public View getView(final int position, View convertView,
							ViewGroup parent) {
			LayoutInflater inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View rowView = inflater.inflate(R.layout.ha_grid,parent, false);
			TextView s= (TextView)rowView.findViewById(R.id.hacks_gridTextView);
			TextView cors= (TextView)rowView.findViewById(R.id.hagridTextView2);
			s.setTypeface(b);
			cors.setTypeface(n);
			TextView des= (TextView)rowView.findViewById(R.id.hagridTextView1);
			des.setTypeface(n);
			des.setText(Controler.descriptions(values.get(position).tag));
			cors.setText("X: "+values.get(position).xcor+ "Y: "+values.get(position).ycor);
			s.setText(values.get(position).tag);
			ImageView up=(ImageView)rowView.findViewById(R.id.hagridImageView2);
			ImageView icon=(ImageView)rowView.findViewById(R.id.hagridImageView1);
			Bitmap b=ImageUtils.drawableToBitmap(getResources().getDrawable(Controler.pics(values.get(position).tag)));
			Bitmap sq=ImageUtils.cropToSquare(b);
			icon.setImageBitmap(sq);
			final ImageView see=(ImageView)rowView.findViewById(R.id.ha_gridImageView);
			up.setOnClickListener(new OnClickListener(){
					@Override
					public void onClick(View v){
						if(position!=0){
							updateDb(position-1,position,getActivity().getApplicationContext());
							ArrayUtils.reArrange(values,position,position-1);
							f.notifyDataSetChanged();
							hackviews=null;
							hackviews=values;
						}
					}


				});

				if(values.get(position).state.startsWith("1")){
					see.setImageResource(R.drawable.show);
					
				
				}else{
					see.setImageResource(R.drawable.hide);
					
				}
				
			see.setOnClickListener(new OnClickListener(){
					@Override
					public void onClick(View v){
						if(values.get(position).state.startsWith("1")){
						update(getActivity().getApplicationContext(),values.get(position).tag,"0");
						see.setImageResource(R.drawable.hide);
							values.get(position).state="0";
						}else{
							
							update(getActivity().getApplicationContext(),values.get(position).tag,"1");
							see.setImageResource(R.drawable.show);
							values.get(position).state="1";
						}
						f.notifyDataSetChanged();
					}
					
					});
				

			return rowView;		
		}
	}


	public void updateDb(int a,int b,Context c){

		Hacks newmoved=new Hacks();
		newmoved.id=a+1;
		newmoved.tag=hackviews.get(b).tag;
		newmoved.xcor=hackviews.get(b).xcor;
		newmoved.ycor=hackviews.get(b).ycor;

		Hacks backed=new Hacks();
		backed.id=b+1;
		backed.tag=hackviews.get(a).tag;
		backed.xcor=hackviews.get(a).xcor;
		backed.ycor=hackviews.get(a).ycor;

		//Sqlite.report(""+newmoved.id+backed.id,c);
		//Sqlite.report(""+newmoved.tag+backed.tag,c);
		String dbName = "makindu";
		String tableViews="views";
		SQLiteDatabase myDb = null;
		try{
			myDb =  c.openOrCreateDatabase(dbName, Context.MODE_PRIVATE, null);

			myDb.execSQL( "UPDATE " + tableViews + " SET tag = '"+newmoved.tag+"' WHERE id="+newmoved.id); 		
			myDb.execSQL( "UPDATE " + tableViews + " SET xcor = '"+newmoved.xcor+"' WHERE id="+newmoved.id ); 		
			myDb.execSQL( "UPDATE " + tableViews + " SET ycor = '"+newmoved.ycor+"' WHERE id="+newmoved.id);

			myDb.execSQL( "UPDATE " + tableViews + " SET tag = '"+backed.tag+"' WHERE id="+backed.id); 		
			myDb.execSQL( "UPDATE " + tableViews + " SET xcor = '"+backed.xcor+"' WHERE id="+backed.id); 		
			myDb.execSQL( "UPDATE " + tableViews + " SET ycor = '"+backed.ycor+"' WHERE id="+backed.id);


		}catch (SQLiteException se ) {
			Toast.makeText(c, "Couldn't update into databasedatabase", Toast.LENGTH_LONG).show();
		} finally {
			PreferenceManager.getDefaultSharedPreferences(getActivity())
				.edit().putString("refresh","Done").commit();
			
			if (myDb != null) {
				//Sqlite.report("updated",c);
			}
		}

	}
	
	
	
	public void update(final Context c,String tag,String state){
		String dbName = "makindu";
		String tableViews="views";
		SQLiteDatabase myDb = null;
		try{
			myDb =  c.openOrCreateDatabase(dbName, Context.MODE_PRIVATE, null);

			myDb.execSQL( "UPDATE " + tableViews + " SET state = '"+state+"' WHERE tag='"+tag+"'" ); 		
		}catch (SQLiteException se ) {
        	Toast.makeText(c, "Couldn't update into databasedatabase", Toast.LENGTH_LONG).show();
        } finally {
			PreferenceManager.getDefaultSharedPreferences(getActivity())
				.edit().putString("refresh","Done").commit();
			
        	if (myDb != null) {
				//Sqlite.report("updated",c);
			}
		}

	}
	
	
}
