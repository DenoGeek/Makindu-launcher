package com.techshare.launcher.fragments;

import android.app.Activity;
import android.os.*;
import android.view.*;
import android.database.*;
import android.database.sqlite.*;
import android.content.Context;
import java.util.*;
import android.widget.ArrayAdapter;
import android.widget.*;
import android.view.View.*;
import com.techshare.launcher.utils.ArrayUtils;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import com.techshare.launcher.Sqlite;
import com.techshare.launcher.R;
import com.techshare.launcher.Controler;

import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.widget.ArrayAdapter;
import android.content.Intent;
import com.techshare.launcher.views.ButtonWithIcons;
public class ConfigureHome extends Fragment
{
	private View view;
	
	private PackageManager manager;
	private ArrayList<AppDetail> apps,appstosave;
	private GridView gv;
	private AppsAdapter adapt;
	private Typeface b,n;
	@Override
	public View onCreateView(LayoutInflater inflater ,
							 ViewGroup container ,
							 Bundle savedInstanceState ) {
		String strtext = getArguments().getString("web");
		String pid=strtext;

		b = Typeface.createFromAsset(getActivity().getApplicationContext().getAssets(),"Bloodthirsty.ttf");	
		n = Typeface.createFromAsset(getActivity().getApplicationContext().getAssets(),"fonts/Walkway_Bold.ttf");
		
		
		view =inflater .inflate( R.layout .configure_home,
								container, false);
		
		TextView fff=(TextView)view.findViewById(R.id.configurehomeTextView2);
		TextView ff=(TextView)view.findViewById(R.id.configure_homeTextView);
		ff.setTypeface(n);
		 fff.setTypeface(b);					
		ButtonWithIcons g=(ButtonWithIcons)view.findViewById(R.id.fwd);
		g.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View v){
					justFinalize();
					ConfigureDock webfrag = new ConfigureDock();
					Bundle bundle = new Bundle();
					bundle.putString("web", "web");
					webfrag.setArguments(bundle);
					FragmentTransaction ft = getActivity().getSupportFragmentManager()
						.beginTransaction();
					ft.setCustomAnimations(R.anim.slideleft,
										   R.anim.slideright);
					ft.replace(R.id.configure_appFrameLayout, webfrag,"fragment");
					// Start the animated transition.
					ft.commit();

				}
			});
			
			
		ButtonWithIcons gi=(ButtonWithIcons)view.findViewById(R.id.back);
		gi.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View v){
					justFinalize();
					ConfigureHacks webfrag = new ConfigureHacks();
					Bundle bundle = new Bundle();
					bundle.putString("web", "web");
					webfrag.setArguments(bundle);
					FragmentTransaction ft = getActivity().getSupportFragmentManager()
						.beginTransaction();
					ft.setCustomAnimations(R.anim.slideleft,
										   R.anim.slideright);
					ft.replace(R.id.configure_appFrameLayout, webfrag,"fragment");
					// Start the animated transition.
					ft.commit();

				}
			});		
			
		if(strtext==null){

			gi.setVisibility(View.GONE);
			g.setOnClickListener(new OnClickListener(){
					@Override
					public void onClick(View r){
						justFinalize();
						Sqlite.report("Saved",getActivity());
					}
				});
		}
			configure();
		return view;
	}
	
	
	public void configure(){
		
		apps= getapps(getActivity().getApplicationContext());
		appstosave=apps;
		//Sqlite.report(""+apps.get(0).label,getActivity().getApplicationContext());
		gv=(GridView)view.findViewById(R.id.configurehomeGridView1);
		 adapt= new AppsAdapter(getActivity().getApplicationContext(),apps);
		gv.setAdapter(adapt);
	}
	
	public ArrayList<AppDetail> getapps(Context context){
		
		manager = context.getPackageManager();
			ArrayList<AppDetail> ap = new ArrayList<AppDetail>();
		Intent i = new Intent(Intent.ACTION_MAIN,
							  null);
		i.addCategory(Intent.CATEGORY_LAUNCHER)
			;
		List<ResolveInfo> availableActivities =
			manager.queryIntentActivities(i, 0);
		for(ResolveInfo ri:availableActivities){
			AppDetail app = new AppDetail();
			app.label = ri.loadLabel(manager);
			app.name =
				ri.activityInfo.packageName;
			app.icon = ri.activityInfo.loadIcon
			(manager);
			if(Sqlite.isHome(""+app.name,getActivity().getApplicationContext())){app.state=1;}else{
			app.state=0;}
			ap.add(app);
		}

		new CompareApps("g",ap,context);
		return ap;
	}
	
	private class AppDetail {
		CharSequence label;
		CharSequence name;
		Drawable icon;
		int state;
	}
	
	
	public class CompareApps implements
	Comparator<AppDetail> {
		private List<AppDetail> apps = new ArrayList<AppDetail>
		();
		Context context;
		public CompareApps(String str,List<AppDetail> apps,
						   Context context) {
			this.apps = apps;
			this.context = context;
			Collections.sort(this.apps, this);
		}
		@Override
		public int compare(AppDetail lhs, AppDetail rhs) {
			// TODO Auto-generated method stub
			return lhs.label.toString().toUpperCase().compareTo
			(rhs.label.toString().toUpperCase());
		}
	}
	
	
	private class AppsAdapter extends ArrayAdapter<String> {
		private final Context context;
		private final ArrayList<AppDetail> values;
		public AppsAdapter(Context context, ArrayList<AppDetail>
								values) {
			super (context, R.layout.configure_apps_grid_item, values);
			this .context = context;
			this .values = values;
			 }

			 @Override
			 public int getCount()
			 {
				 // TODO: Implement this method
				 return values.size();
			 }
		
		
		
		@Override
		public View getView(final int position, View convertView,
							ViewGroup parent) {
			LayoutInflater inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View rowView = inflater.inflate(R.layout.configure_apps_grid_item,parent, false);
			
			TextView app=(TextView)rowView.findViewById(R.id.configureappsgriditemTextView1);
			ImageView icon=(ImageView)rowView.findViewById(R.id.configureappsgriditemImageView1);
			final ImageView tick=(ImageView)rowView.findViewById(R.id.configureappsgriditemImageView2);
			
			app.setText(values.get(position).label);
			icon.setImageDrawable(values.get(position).icon);
			
			if(values.get(position).state==0){tick.setVisibility(View.GONE);}else{
				tick.setVisibility(View.VISIBLE);
			}
			icon.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View v){
					
					if(tick.getVisibility()==View.VISIBLE){
						tick.setVisibility(View.GONE);
						values.get(position).state=0;
						adapt.notifyDataSetChanged();
						appstosave=null;
						appstosave=values;
						updateCounter();
					}else{
						tick.setVisibility(View.VISIBLE);
						values.get(position).state=1;
						adapt.notifyDataSetChanged();
						appstosave=null;
						appstosave=values;
						updateCounter();
					}
					
				}
			});
			
		return rowView;
			}
		}
		
		private int selectedApps(){
			int a=0;
			
			if(appstosave.size()>0){
			for(int i=0;i<appstosave.size();i++){
				if(appstosave.get(i).state==1){
					a++;
				}
				
			}
			}
			
			return a;
		}
		
		private void updateCounter(){
			String definer;
			if(selectedApps()==1){definer="App";}else{definer="Apps";}
			TextView v=(TextView)view.findViewById(R.id.configurehomeTextView1);
			v.setText(""+selectedApps()+" "+definer+" Selected ");
		}
		
		public void justFinalize(){
			if(appstosave.size()>0){
				for(int i=0;i<appstosave.size();i++){
					int[] s={1,2};
					int screen=s[new Random().nextInt
					(s.length)];
					if(appstosave.get(i).state==1){
						if(!Sqlite.isHome(""+appstosave.get(i).name,getActivity().getApplicationContext())){
						Sqlite.insertApp(getActivity().getApplicationContext(),""+appstosave.get(i).label,""+appstosave.get(i).name,screen);
						}
					}else{
						if(Sqlite.isHome(""+appstosave.get(i).name,getActivity().getApplicationContext())){
							Sqlite.deleteApp(getActivity().getApplicationContext(),""+appstosave.get(i).name);
						}
					}

				}
			}
		}
	
}
