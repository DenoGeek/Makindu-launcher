package com.techshare.launcher;

import android.app.admin.DeviceAdminReceiver;
public class MyAdminReceiver extends
DeviceAdminReceiver{
}
