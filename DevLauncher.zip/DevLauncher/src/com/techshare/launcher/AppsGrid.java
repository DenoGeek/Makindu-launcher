package com.techshare.launcher;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.*;
import android.view.View.*;
import android.widget.ImageView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.GridView;
import android.widget.TextView;
import android.graphics.*;
import android.graphics.Paint.*;
import android.graphics.drawable.shapes.*;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.Drawable;
import android.widget.ProgressBar;
import android.os.Handler;
import android.os.Bundle;
import android.os.SystemClock;
import java.util.Random;
import android.content.*;
import android.content.pm.PackageManager;
import java.util.*;
import android.content.pm.ResolveInfo;
import android.widget.ArrayAdapter;
import android.widget.PopupMenu;
import android.view.MenuItem;
import java.lang.reflect.Field;
import android.widget.Toast;
import android.net.Uri;
import android.os.Build;
import android.widget.*;
import android.widget.AdapterView.*;
import android.preference.PreferenceManager;
import android.widget.AbsListView.OnScrollListener;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;

import com.easyandroidanimations.library.Animation;
import com.easyandroidanimations.library.AnimationListener;
import com.easyandroidanimations.library.ShakeAnimation;
import com.easyandroidanimations.library.FlipVerticalAnimation;
import android.view.ViewDebug.*;


public class AppsGrid extends FrameLayout
{
	
	private String title,footer;
	public String tag;
	int topCol;
	private PackageManager manager;
	private ArrayList<AppDetail> apps;
	private LinearLayout g;
	private ActionGridView opt;
	private ImageView app;
	private TextView det;
	private AppsAdapter adapt;
	public AppsGrid(Context context, AttributeSet attrs){
		super(context, attrs);
		//paint object for drawing in onDraw
		
		tag="";
		//at this point try fetching custom attributes
		TypedArray arr = context.getTheme().obtainStyledAttributes
		(attrs,
		 R.styleable.CustomGrid, 0, 0);


		try {
			//get the text and colors specified using thenames in attrs.xml
			title = arr.getString(R.styleable.CustomGrid_gridTitle);
			footer = arr.getString(R.styleable.CustomGrid_gridFooter);//0 is default
			topCol = arr.getInteger(R.styleable.CustomGrid_gridTitleBg, 0);
		} finally {
			arr.recycle();
		}
	
		LinearLayout.LayoutParams layoutParams = new
			LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.FILL_PARENT,
			LinearLayout.LayoutParams.FILL_PARENT);
		layoutParams.setMargins(0, 5, 0, 0);


		
		//this.setPadding(5,5,5,5);
		this.setLayoutParams(layoutParams);
		//this.setBackground(getResources().getDrawable(R.drawable.glas));
		
		
		
		
		

		manager = context.getPackageManager();
		apps = new ArrayList<AppDetail>();
		Intent i = new Intent(Intent.ACTION_MAIN,
							  null);
		i.addCategory(Intent.CATEGORY_LAUNCHER)
			;
		List<ResolveInfo> availableActivities =
			manager.queryIntentActivities(i, 0);
		for(ResolveInfo ri:availableActivities){
			AppDetail app = new AppDetail();
			app.label = ri.loadLabel(manager);
			app.name =
				ri.activityInfo.packageName;
			app.icon = ri.activityInfo.loadIcon
			(manager);
			apps.add(app);
		}

		new CompareApps("g",apps,context);
		g=new LinearLayout(context);
		GridView s=new GridView(context);
		FrameLayout.LayoutParams spar = new
			FrameLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT,
									 LinearLayout.LayoutParams.FILL_PARENT);
		spar.gravity=Gravity.TOP | Gravity.CENTER_HORIZONTAL;
		spar.setMargins(3,2,3,3);
		
		s.setLayoutParams(spar);
		
		final float ins= context.getResources
		().getDimension(R.dimen.app_width);
		
		s.setNumColumns(GridView.AUTO_FIT);
		s.setColumnWidth((int)ins+30);
		s.setVerticalSpacing(20);
		s.setHorizontalSpacing(20);
		s.setStretchMode
		(GridView.STRETCH_SPACING_UNIFORM);
		s.setPadding(2,2,2,5);
		
		
		adapt=new AppsAdapter(context,apps);
		s.setAdapter(adapt);
		s.setOnScrollListener(new scrola());
		this.addView(s);
		
		//handle the popup menu
		final float inPixels= context.getResources
		().getDimension(R.dimen.app_width);
		
		final float HeightinPixels= context.getResources
		().getDimension(R.dimen.actionsheet_grid);
		final float WidthinPixels= context.getResources
		().getDimension(R.dimen.actionsheet_grid_width);
		
		
		FrameLayout.LayoutParams gpar = new
			FrameLayout.LayoutParams((int)WidthinPixels,(int)HeightinPixels);
			gpar.gravity=Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL;
			gpar.setMargins(1,1,1,1);
			g.setOrientation(LinearLayout.VERTICAL);
			
		g.setLayoutParams(gpar);
		
		
		
		
		LinearLayout top=new LinearLayout(context);
		LinearLayout.LayoutParams toppar = new
			LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT);
		top.setLayoutParams(toppar);
		top.setPadding(10,0,10,0);
		top.setBackgroundColor(Color.WHITE);
		top.setOrientation(LinearLayout.HORIZONTAL);
		
		app=new ImageView(context);
		LinearLayout.LayoutParams apppar = new
		LinearLayout.LayoutParams((int)inPixels,(int)inPixels);
		app.setPadding(8,8,8,8);
		app.setLayoutParams(apppar);
		RoundRectShape rect = new RoundRectShape(
			new float[] {30,30, 30,30, 30,30, 30,30},
			null,
			null);
		ShapeDrawable bg = new ShapeDrawable(rect);
		bg.getPaint().setColor(Color.WHITE);
		
		app.setBackgroundDrawable(bg);
		app.setImageResource(R.drawable.ico);
		top.addView(app);
		
		 det=new TextView(context);
		det.setCompoundDrawablesWithIntrinsicBounds
		(0,0, android.R.drawable.ic_delete , 0);
		LinearLayout.LayoutParams detpar = new
			LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT,40);
		detpar.setMargins(10,10,10,10);
			det.setLayoutParams(detpar);
	
		det.setBackgroundColor(Color.WHITE);
		top.addView(det);
		det.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				closeg();
			}
		});
		
		 opt=new ActionGridView(context);
		LinearLayout.LayoutParams optzpar = new
			LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT,LinearLayout.LayoutParams.FILL_PARENT);
		opt.setLayoutParams(optzpar);
		
		
		g.addView(top);
		g.addView(opt);
		g.setVisibility(View.GONE);
		g.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.pop_menu_bg));
		this.addView(g);
		
	}
		
	
	private class AppsAdapter extends ArrayAdapter<String> {
		private final Context context;
		private final ArrayList<AppDetail> values;
		public AppsAdapter(Context context, ArrayList<AppDetail>
						   values) {
			super (context, R.layout.configure_apps_grid_item, values);
			this .context = context;
			this .values = values;
		}

		@Override
		public int getCount()
		{
			// TODO: Implement this method
			return values.size();
		}



		@Override
		public View getView(final int position, View convertView,
							ViewGroup parent) {
			LayoutInflater inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			WidgetApp f=new WidgetApp(context,values.get(position).label.toString(),values.get(position).name.toString());
			
			f.setOnClickListener(new clika());
			f.setTag(position);
		
			return f;
			}
	}
	
		
	public void showInstalledAppDetails(String
										packageName,Context c) {
		final int apiLevel = Build.VERSION.SDK_INT;
		Intent intent = new Intent();
		if (apiLevel >= 9) {
			intent.setAction(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
			intent.setData(Uri.parse("package:" + packageName))
				;
		} else {
			final String appPkgName = (apiLevel == 8 ? "pkg" :
				"com.android.settings.ApplicationPkgName");
			intent.setAction(Intent.ACTION_VIEW);
			intent.setClassName("com.android.settings",
								"com.android.settings.InstalledAppDetails");
			intent.putExtra(appPkgName, packageName);
		}
		// Start Activity
		intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		c.startActivity(intent);
	}
	

	private class Longer implements OnLongClickListener
	{

		@Override
		public boolean onLongClick(View p1)
		{
			// TODO: Implement this method
			return false;
		}	
	}
		
	
	
	
	
	private class clika implements OnClickListener
	{

		@Override
		public void onClick(final View v)
		{
			// TODO: Implement this method
			
			new ShakeAnimation(v)
			.setDuration(100)
			.setNumOfShakes(1)
				.setListener(new AnimationListener(){
					@Override
					public void onAnimationEnd(Animation o){
				if(g.getVisibility()==View.GONE){
						g.setVisibility(View.VISIBLE);			
						// new HighlightAnimation(g).animate();
						}
			
			
			tag=v.getTag().toString();
			app.setImageDrawable(apps.get(Sqlite.inTise(tag)).icon);
			if(det.getText().toString().equals(apps.get(Sqlite.inTise(tag)).label)){
				
				
				
				closeg();
				new FlipVerticalAnimation(v)
				.setListener(new AnimationListener(){
					@Override
					public void onAnimationEnd(Animation o){
						Intent LaunchIntent = getContext().getPackageManager()
							.getLaunchIntentForPackage(""+apps.get(Sqlite.inTise(tag)).name);
						LaunchIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
						getContext().startActivity( LaunchIntent );
						
					}
				})
				.animate();
				//v.setVisibility(View.GONE);
				/**/
				
				
			}else{
			det.setText(apps.get(Sqlite.inTise(tag)).label);}
			/*
			StartPT = new PointF( v.getX(),
								 v.getY() );*/
			opt.setOnItemClickListener(new SheetGrid());
			//showInstalledAppDetails(apps.get(Sqlite.inTise(tag)).name.toString(),getContext());
			
		}
		
		}).animate();

	
		}
	}
	
	private class scrola implements OnScrollListener{
		private int currentScrollState,currentVisibleItemCount,currentFirstVisibleItem;
	@Override
	public void onScroll(AbsListView view,
						 int firstVisibleItem, int visibleItemCount, int totalItemCount)
	{
		if(g.getVisibility()==View.VISIBLE){
			g.setVisibility(View.GONE);}
		if (firstVisibleItem + visibleItemCount >= totalItemCount){
            // End has been reached
			g.setVisibility(View.GONE);

        }
		this.currentFirstVisibleItem = firstVisibleItem;
    	this.currentVisibleItemCount = visibleItemCount;
    }
	@Override
	public void onScrollStateChanged(AbsListView view, int scrollState){
		this.currentScrollState = scrollState;
		this.isScrollCompleted();
		
		}
		
		private void isScrollCompleted() {
			if (this.currentVisibleItemCount > 0 &&
				this.currentScrollState == SCROLL_STATE_IDLE) {
				/*** In this way I detect if there's been a scroll which has completed ***/
				/*** do the work! ***/
				
				closeg();
			}
		}
	}
	
	private class SheetGrid implements OnItemClickListener{
		
		
		
		@Override
		public void onItemClick ( AdapterView <?> parent,
								 View view, int position, long id ) {
									 
			int taag=Sqlite.inTise(""+tag);
			//Sqlite.report(""+taag,getContext());
					String t=apps.get(taag).name.toString();	
			String n=apps.get(taag).label.toString();
			switch(position){

				case 0:
					closeg();
					Intent a=new Intent(getContext(),LaunchActivity.class);
					a.putExtra("launch",t);
					a.addFlags(a.FLAG_ACTIVITY_NEW_TASK);
					getContext().startActivity(a);
					

					break;
				case 1:
					closeg();
					Intent LaunchIntent = getContext().getPackageManager()
						.getLaunchIntentForPackage(t);
					LaunchIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					getContext().startActivity( LaunchIntent );
					
					break;
				case 2:
					closeg();
					
						Uri packageURI = Uri.parse("package:"+t);
						Intent uninstallIntent = new Intent
						(Intent.ACTION_UNINSTALL_PACKAGE,
						 packageURI);
						uninstallIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
						getContext().startActivity(uninstallIntent);
					
					break;

				case 3:
					closeg();
					showInstalledAppDetails(t,getContext());
					
					break;
				case 4:

					if(Sqlite.isFav(t,getContext())){
						Sqlite.delete(getContext(),t);
						closeg();
					}else{

						Sqlite.insert(getContext(),t);
						closeg();
					}

					
					break;
				case 5:

					if(Sqlite.isFav(t,getContext())){
						Sqlite.delete(getContext(),t);

						closeg();
					}else{

						Sqlite.insert(getContext(),t);
						closeg();
					}
					
					break;
					
					

				case 6:
					if(Sqlite.isHome(t,getContext())){
						Sqlite.report("This app is already in home",getContext());
					}else{
					Sqlite.insertApp(getContext(),n,t,1);
					}
					
					break;
			case 7:
				if(!Sqlite.isDockFull(getContext())){
					Sqlite.insertDock(getContext(),t);
				}else{
					Sqlite.report("Please Remove an app from dock by long pressing it",getContext());
				}
				break;


			}							 
								 
									 }
		
	}
	
	private void closeg(){
		
		new ShakeAnimation(g).setDuration(200).setListener(new AnimationListener(){
			@Override
			public void onAnimationEnd(Animation f){
				g.setVisibility(View.GONE);
			}
			
		}).animate();
	}
	

}
