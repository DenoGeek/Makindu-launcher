package com.techshare.launcher.views;

import android.widget.*;
import android.view.*;
import java.util.*;
import com.techshare.launcher.R;
import android.util.AttributeSet;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Typeface;
import android.graphics.*;
import com.techshare.launcher.utils.ImageUtils;
public class ButtonWithIcons extends LinearLayout
{
	
	private String text;
	private Drawable pic;
	private int bgc,borderc,txtcolor;
	public ButtonWithIcons(Context context, AttributeSet attrs){
		super(context, attrs);
		//paint object for drawing in onDraw


		//at this point try fetching custom attributes
		TypedArray a = context.getTheme().obtainStyledAttributes
		(attrs,
		 R.styleable.ButtonPic, 0, 0);


		try {
			//get the text and colors specified using thenames in attrs.xml
			text = a.getString(R.styleable.ButtonPic_text);
		    pic=a.getDrawable(R.styleable.ButtonPic_pic);
			bgc=a.getColor(R.styleable.ButtonPic_color,Color.parseColor("#574356"));
			txtcolor=a.getColor(R.styleable.ButtonPic_txtcolor,Color.parseColor("#000000"));
			borderc=a.getColor(R.styleable.ButtonPic_bodacolor,Color.parseColor("#574356"));
			} finally {
			a.recycle();
		}
		
		
		//now add a textview and ImageView to the linearlayout
		this.setOrientation(LinearLayout.HORIZONTAL);
		
		LinearLayout.LayoutParams photoParams = new
			LinearLayout.LayoutParams(50,50);
		photoParams.setMargins(2, 3, 0, 3);
		
		LinearLayout.LayoutParams textParams = new
			LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,40);
		textParams.setMargins(2, 3, 10, 3);
		
		if(text.equals("")){text="mybutton";}
		if(pic==null){pic= context.getResources().getDrawable(R.drawable.ico);}
		Bitmap b= ImageUtils.drawableToBitmap(pic);
		Bitmap caso=ImageUtils.getCircleBitmap(b);
		ImageView g=new ImageView(context);
		g.setLayoutParams(photoParams);
		g.setImageBitmap(caso);
		
		Typeface nice = Typeface.createFromAsset(context.getAssets(),"fonts/Walkway_Bold.ttf");
		TextView t=new TextView(context);
		t.setLayoutParams(textParams);
		t.setText(text);
		t.setTypeface(nice);
		t.setTextColor(txtcolor);
		t.setTextSize(14);
		t.setGravity(Gravity.CENTER);
		this.addView(g);
		this.addView(t);
		
		
		GradientDrawable shape = new GradientDrawable();
		shape.setShape(GradientDrawable.RECTANGLE);
		shape.setCornerRadii(new float[] { 3, 3,				 3, 3, 3, 3, 3, 3 });
		shape.setColor(bgc);
		shape.setStroke(1, borderc);
		
		this.setBackgroundDrawable(shape);
		
	}
	
	
	
	
}
