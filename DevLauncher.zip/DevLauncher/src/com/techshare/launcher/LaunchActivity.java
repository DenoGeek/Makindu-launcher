package com.techshare.launcher;
import android.app.*;
import android.view.*;
import android.os.*;
import android.widget.*;
import android.content.*;
import java.util.Random;
public class LaunchActivity extends Activity
{
	private ProgressBar customProgress;
	private TextView pane,progressDisplay;
	private String appl;
	@Override
	protected void onCreate(Bundle savesInstanceState){
		super.onCreate(savesInstanceState);
		setContentView(R.layout.launch);
		
		Bundle b=getIntent().getExtras();
		if(b!=null){
			
		appl=b.getString("launch");}else{
			
			
		}

		customProgress = (ProgressBar)findViewById(R.id.customProgress);
        progressDisplay = (TextView)findViewById(R.id.progressDisplay);
		pane=(TextView)findViewById(R.id.header);
		
		
		
	
	
	new CountDownTimer(3000, 150) { // adjust the
		//milli seconds here
		int progress;
	public void onTick(long millisUntilFinished) {
		String[] opener={
			appl+"Erasing all recent histories",
			appl+"Pooting system and removing all system apps",
			"killing kernel with forceful running of operatios",
			appl+"Enabling usb debuging for makindu recovery",
			"Entering sleeping procedure"

		};

		progress+=5;
		customProgress.setProgress(progress);
		progressDisplay.setText(progress+"%");
		Random r = new Random();
		int max=opener.length;
		int i1 = r.nextInt(max - 0) + 0;
		addMessage(opener[i1]);

	}



	public void onFinish() {
		
		lock();
	}
	}.start();

}


       
        public void lock() {
			
			Intent LaunchIntent = getApplicationContext().getPackageManager()
				.getLaunchIntentForPackage(appl);
			getApplicationContext().startActivity( LaunchIntent );
       finish();
			}

	
	// function to append a string to a TextView as a new line
// and scroll to the bottom if needed
	private void addMessage(String msg) {
		// append the new string
		pane.append(msg + "\n");
		// find the amount we need to scroll.  This works by
		// asking the TextView's internal layout for the position
		// of the final line and then subtracting the TextView'sheight
		/*final int scrollAmount = pane.getLayout()
		 .getLineTop(pane.getLineCount()) -
		 pane.getHeight();
		 // if there is no need to scroll, scrollAmount will be <=0
		 if (scrollAmount > 0)
		 pane.scrollTo(0, scrollAmount);
		 else
		 pane.scrollTo(0, 0);*/
	}
	
	
}
