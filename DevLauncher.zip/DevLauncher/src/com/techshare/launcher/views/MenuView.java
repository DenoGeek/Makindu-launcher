package com.techshare.launcher.views;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.view.*;
import android.content.Context;
import android.view.View.*;
import android.widget.*;
import com.techshare.launcher.views.*;
import com.techshare.launcher.R;
import android.graphics.Color;
import android.widget.SearchView.*;
import com.techshare.launcher.Sqlite;
import android.graphics.Typeface;
import android.view.View.OnClickListener;
import com.easyandroidanimations.library.*;
import java.security.*;
import java.util.*;
import com.techshare.launcher.SettingsActivity;
import com.techshare.launcher.Controler;
import android.widget.AdapterView.*;
public class MenuView extends Service {

	private WindowManager windowManager;
	private actionBtn instructparento;

	private ImageView main;
	private LinearLayout container;
	private int id;
	private ActionGridView opt;
	WindowManager.LayoutParams params;

	@Override
	public void onCreate() {
		super.onCreate();

		}



	@Override
	public void onDestroy() {
		super.onDestroy();
		if (instructparento!= null)
			windowManager.removeView(instructparento);
	}

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public int onStartCommand (Intent intent,
							   int flags, int startId){
		String Ide = intent.getStringExtra
		("id");
		
		windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

		id=Sqlite.inTise(Ide);
		switch(Sqlite.inTise(Ide)){
				
			case 0:
				instructparento=new actionBtn(getApplicationContext());
				break;
			
			
		}

		
		


		params= new WindowManager.LayoutParams(
			WindowManager.LayoutParams.FILL_PARENT,
			WindowManager.LayoutParams.FILL_PARENT,
			WindowManager.LayoutParams.TYPE_PHONE,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
			PixelFormat.TRANSLUCENT);

		params.gravity = Gravity.TOP | Gravity.LEFT;
		params.x = 0;
		params.y = 100;


		windowManager.addView(instructparento,params);
		
		
		return START_STICKY;
	}
	

	private class Movie implements OnTouchListener{
		private int initialX;
		private int initialY;
		private float initialTouchX;
		private float initialTouchY;

		@Override
		public boolean onTouch(View v, MotionEvent event) {
			switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:
					initialX = params.x;
					initialY = params.y;
					initialTouchX = event.getRawX();
					initialTouchY = event.getRawY();
					return true;
				case MotionEvent.ACTION_UP:


					return true;
				case MotionEvent.ACTION_MOVE:


					params.x = initialX
						+ (int) (event.getRawX() - initialTouchX);
					params.y = initialY
						+ (int) (event.getRawY() - initialTouchY);
					windowManager.updateViewLayout(instructparento, params);
					return true;
			}
			return false;
		}

	}


	//This is the custim view kimoda that ill add
	private class actionBtn extends LinearLayout{

		public actionBtn(Context context){
			super(context);

			WindowManager windowManager = (WindowManager)
				context
				.getSystemService(Context.WINDOW_SERVICE);

			int width=windowManager.getDefaultDisplay()
				.getWidth();
			int height=windowManager.getDefaultDisplay()
				.getHeight();

			final float inPixels= context.getResources
			().getDimension(R.dimen.intro_height);
			
			final float inPixiels= context.getResources
			().getDimension(R.dimen.txt_height);
			
			LinearLayout.LayoutParams mpar = new
				LinearLayout.LayoutParams(width,height);
			mpar.setMargins(5,5,0,0);

			
			Typeface b = Typeface.createFromAsset(getApplicationContext().getAssets(),"fonts/Walkway_Bold.ttf");
			
			
			LinearLayout.LayoutParams tpar = new
				LinearLayout.LayoutParams((int)inPixiels,LinearLayout.LayoutParams.WRAP_CONTENT);
			
				
				
			//The gridView part	
			opt=new ActionGridView(context);
			LinearLayout.LayoutParams optzpar = new
				LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT);
			opt.setLayoutParams(optzpar);
			opt.setOnItemClickListener(new gika());
			Button bt=new Button(context);
			LinearLayout.LayoutParams btpar = new
				LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT);
			btpar.setMargins(4,30,4,5);
				bt.setLayoutParams(btpar);
			bt.setText("Got It");
			bt.setBackgroundResource(R.drawable.rounder);
			bt.setOnClickListener(new OnClickListener(){
					@Override
					public void onClick(View b){
						Controler.ofsetBoolean(getApplicationContext(),id);
						stopService(new Intent(getApplication(), MenuView.class));
					}

				});

				
			this.setWeightSum(1);
			this.setGravity(Gravity.BOTTOM);
			this.setOrientation(LinearLayout.VERTICAL);
			//this.addView(bt);
			this.addView(opt);
			this.setOnClickListener(new OnClickListener(){
					@Override
					public void onClick(View b){
						Controler.ofsetBoolean(getApplicationContext(),id);
						stopService(new Intent(getApplication(), MenuView.class));
					}

				});
			this.setBackgroundColor(Color.parseColor("#89000000"));
			this.setLayoutParams(mpar);
		}

	}
	
	
	private class ActionGridView extends GridView
	{ 

		public ActionGridView(Context context){
			super(context);
			this.setNumColumns(3);
			this.setColumnWidth(110);
			//now set the grid view adapters
			String options[]={"Setting","Refresh","Float Browser","Details","Favourite","Unfavourite","Add to home","Add to Dock"};
			int icons[]={R.drawable.settings,R.drawable.update,R.drawable.net,R.drawable.det,R.drawable.addfav,R.drawable.fav,R.drawable.home,R.drawable.dock};
			List<HashMap<String,String>> aList = new
				ArrayList<HashMap<String,String>>();
			for (int i= 0;i< 3 ;i++){
				HashMap<String, String> hm = new
					HashMap<String,String>();
				hm.put( "txt" , options[i]);
				hm.put( "flag" , Integer.toString(icons[i]) );
				aList.add(hm);
			}
			String[] from = { "flag" ,"txt" };
			int [] to = { R.id.flag,R.id.txt};
			SimpleAdapter adapter = new SimpleAdapter(context, aList, R.layout.gridview_layout, from, to);


			this.setAdapter(adapter);
			this.setBackgroundColor(Color.parseColor("#ffffff"));
		}
	
	}
	
	private class gika implements OnItemClickListener
	{

		@Override
		public void onItemClick(AdapterView<?> p1, View p2, int p3, long p4)
		{
			// TODO: Implement this method
			stopService(new Intent(getApplication(), MenuView.class));
			switch(p3){
				case 1:
					int pid = android.os.Process.myPid();
					android.os.Process.killProcess(pid);
					Toast.makeText(getApplicationContext(),"Restarting",Toast.LENGTH_SHORT).show();
					Intent intent = new Intent(Intent.ACTION_MAIN);
					intent.addCategory(Intent.CATEGORY_HOME);
					getApplicationContext().startActivity(intent);
					
					break;
				case 0:
					Intent a=new Intent(getApplicationContext(),SettingsActivity.class);
					a.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					startActivity(a);
					break;
					
				case 2:
					startService(new Intent(getApplication(), FloatingBrowser.class));
					break;
				
				
			}
		}

		
		
		
	}

}
