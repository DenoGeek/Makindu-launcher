package com.techshare.launcher.views;
import android.content.Context;
import android.widget.*;
import android.view.*;
import com.techshare.launcher.R;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import java.util.*;
import android.database.*;
import android.database.sqlite.*;
import android.content.Intent;
import android.view.animation.*;
import android.animation.*;
import android.os.Vibrator;
import com.techshare.launcher.Sqlite;


import com.easyandroidanimations.library.PuffOutAnimation;
import com.easyandroidanimations.library.Animation;
import com.easyandroidanimations.library.AnimationListener;



public class DockBar extends LinearLayout
{
	private List<dockApp> f;
		int width,height;
		public DockBar(final Context context){
			super(context);
			width=LinearLayout.LayoutParams.FILL_PARENT;
			final float inPixels= context.getResources
			().getDimension(R.dimen.app_width);
			
			height=(int)inPixels;
			FrameLayout.LayoutParams layoutParams = new
				FrameLayout.LayoutParams(width,height);
			layoutParams.setMargins(0, 6, 6, 1);
			
			this.setLayoutParams(layoutParams);
			this.setOrientation(LinearLayout.HORIZONTAL);
			this.setGravity(Gravity.CENTER);
			 f=dockApps(context);
			
			
			for(int i=0;i<5;i++){
				
				app g=new app(context);
				g.setImageDrawable(f.get(i).icon);
				g.setTag(i);
				
				g.setOnClickListener(new lika());
				g.setOnLongClickListener(new longlika());
				this.addView(g);
				this.setBackgroundResource(R.drawable.flatglas);
				
			}
			
			//this.setBackgroundColor(Color.parseColor("#"));
		}

	
		
		private class app extends ImageView{
			
			int w,h,divisor;
			
			public app(Context context){
				
				super(context);
				
				final float inPixels= context.getResources
				().getDimension(R.dimen.dock_app_width);
				w=h=(int)inPixels;
				LinearLayout.LayoutParams layoutParams = new
					LinearLayout.LayoutParams(w,w);
					layoutParams.setMargins(6,2,6,2);
					this.setLayoutParams(layoutParams);
				
			}
		}
		
		
		private Drawable getIcon(String t,Context c){
			Drawable d;
			d=null;
			d=c.getResources().getDrawable(R.drawable.ico);
			try {
				d = c.getPackageManager().getApplicationIcon
				(t);
				
			} catch(Exception  e) {
				//Sqlite.delete(c,t);

				e.printStackTrace();
			}
			return d;
		}
		
		
		private class dockApp{
			int id;
			String name;
			Drawable icon;
			
		}
		
		
		private List<dockApp> dockApps(Context c){
			List<dockApp> s= new ArrayList<dockApp>();
			
			
			
			int counter=0;
			String dbName = "makindu";
			String tableName = "dock";
			SQLiteDatabase myDb = null;

		
			//check whether ths array exists in database
			try {


				//Instantiate sampleDB object
				myDb =  c.openOrCreateDatabase(dbName, c.MODE_WORLD_WRITEABLE, null);
				//Create Cursor object to read versions from the table
				Cursor a = myDb.rawQuery("SELECT * FROM "+tableName, null);
				int deficit=5-a.getCount();
				//If Cursor is valid
				if (a != null ) {
					//Move cursor to first row
					if  (a.moveToFirst()) {
						do {
							//Get version from Cursor
							String nm = a.getString(a.getColumnIndex("name"));
							int id = a.getInt(a.getColumnIndex("id"));
							Drawable g=getIcon(nm,c);
							
							dockApp f=new dockApp();
							f.name=nm;
							f.icon=g;
							f.id=id;
							s.add(f);
							//Sqlite.report( nm+" "+counter,c);
							
							
						}while (a.moveToNext()); //Move to next row
					} 
				}
				for (int i=0;i<deficit;i++){
					dockApp f=new dockApp();
					f.name="nm";
					f.icon=getIcon("",c);
					f.id=6-i;
					s.add(f);
				}
				
			} catch (SQLiteException se ) {
				//Server.newload(c);
			} finally {
				if (myDb== null) {
					//sampleDB.execSQL("DELETE FROM " + tableName);
					//sampleDB.close();
				}
			}
			
			return s;
		}
		
	public class lika implements OnClickListener
	{

		@Override
		public void onClick(View p1)
		{
			// TODO: Implement this method
		int pos=p1.getTag();
		
			if(f.get(pos).name.equals("nm")){}else{
			Intent LaunchIntent = getContext().getPackageManager()
				.getLaunchIntentForPackage(f.get(pos).name);
			LaunchIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			getContext().startActivity( LaunchIntent );

			}
		}
	}
	
	public class longlika implements OnLongClickListener
	{

		@Override
		public boolean onLongClick(final View p1)
		{
			// TODO: Implement this method
			
			int pos=p1.getTag();
			
			if(f.get(pos).name.equals("nm")){}else{
				Sqlite.deleteDock(getContext(),f.get(pos).name);
				Vibrator v = (Vibrator)
					getContext().getSystemService
				(Context.VIBRATOR_SERVICE);
				// Vibrate for 500 milliseconds
				v.vibrate(500);
				new PuffOutAnimation(p1).setListener(new AnimationListener(){
					@Override
					public void onAnimationEnd(Animation n){
						p1.setVisibility(View.GONE);
						
					}
				}).animate();
				
			}
			
			return true;
		}

	}
}
