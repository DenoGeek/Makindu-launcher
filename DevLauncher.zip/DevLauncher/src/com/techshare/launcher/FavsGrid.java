package com.techshare.launcher;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.*;
import android.view.View.*;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.LinearLayout;
import android.widget.GridView;
import android.widget.Toast;
import android.widget.TextView;
import android.graphics.*;
import android.graphics.Paint.*;
import android.graphics.drawable.shapes.*;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.Drawable;
import android.widget.ProgressBar;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.SystemClock;
import java.util.Random;
import android.content.*;
import android.content.pm.PackageManager;
import java.util.*;
import android.database.*;
import android.database.sqlite.*;
import android.content.pm.ResolveInfo;
import android.widget.ArrayAdapter;
import android.content.pm.PackageManager;
import android.content.pm.ApplicationInfo;


public class FavsGrid extends GridView
{

	private String title,footer;
	int topCol;
	private PackageManager manager;
	private List<AppDetail> apps;


	public FavsGrid(Context context, AttributeSet attrs){
		super(context, attrs);
		//paint object for drawing in onDraw


		//at this point try fetching custom attributes
		TypedArray a = context.getTheme().obtainStyledAttributes
		(attrs,
		 R.styleable.CustomGrid, 0, 0);


		try {
			//get the text and colors specified using thenames in attrs.xml
			title = a.getString(R.styleable.CustomGrid_gridTitle);
			footer = a.getString(R.styleable.CustomGrid_gridFooter);//0 is default
			topCol = a.getInteger(R.styleable.CustomGrid_gridTitleBg, 0);
		} finally {
			a.recycle();
		}

		WindowManager windowManager = (WindowManager)
			context
			.getSystemService(Context.WINDOW_SERVICE);
		
		

		int width=windowManager.getDefaultDisplay()
			.getWidth()/10*7;
		int height=windowManager.getDefaultDisplay()
			.getHeight()/10*5;
		LinearLayout.LayoutParams layoutParams = new
			LinearLayout.LayoutParams(
			width,
			height);
		layoutParams.setMargins(15, 6, 15, 10);


		loadApps(context);
		//this.setPadding(5,5,5,5);
		this.setLayoutParams(layoutParams);
		//this.setBackground(getResources().getDrawable(R.drawable.glas));



	}


	public void loadApps(final Context c){
		String dbName = "makindu";
		String tableName = "appslist";
		SQLiteDatabase myDb = null;

		StringBuilder hk=new StringBuilder();


		//check whether ths array exists in database
		try {


        	//Instantiate sampleDB object
        	myDb =  c.openOrCreateDatabase(dbName, c.MODE_WORLD_WRITEABLE, null);
        	//Create Cursor object to read versions from the table
        	Cursor a = myDb.rawQuery("SELECT * FROM "+tableName+"", null);
        	//If Cursor is valid
        	if (a != null ) {
        		//Move cursor to first row
        		if  (a.moveToFirst()) {
					do {
						//Get version from Cursor
						String f = a.getString(a.getColumnIndex("package"));
						hk.append(f+":");

					}while (a.moveToNext()); //Move to next row
				} 
        	}

		} catch (SQLiteException se ) {
			//Server.newload(c);
			Sqlite.report("Error fetching",c);
        } finally {


			//sampleDB.execSQL("DELETE FROM " + tableName);
			//sampleDB.close();
			final String ap[]=hk.toString().split(":");
			if(ap.length>0){
			final ArrayList<String> items
				= new ArrayList<String>();
			items.addAll(Arrays.asList(ap));
			//Sqlite.report(ap[0],c);
			ArrayAdapter<String> adapter = new
				ArrayAdapter<String>(c,
									 R.layout.grid_layout,
									 items) {
				@Override
				public View getView(int position,
									View convertView, ViewGroup parent) {
					if(convertView == null){
						LayoutInflater inflater = (LayoutInflater)
							c.getSystemService( Context.LAYOUT_INFLATER_SERVICE );

						convertView
							= inflater.inflate(R.layout.grid_layout, null);
					}

					ImageView appIcon =
						(ImageView)convertView.findViewById(R.id.icon);
					//appIcon.setImageDrawable(apps.get(position).icon);
					TextView appLabel =
						(TextView)convertView.findViewById(R.id.label);
					appLabel.setText(items.get(position));
					String t=items.get(position);
					
					try {
						Drawable d = c.getPackageManager().getApplicationIcon
					(t);
						appIcon.setBackgroundDrawable(d);
					} catch(Exception  e) {
						Sqlite.delete(c,t);
						
						e.printStackTrace();
					}
					

					/*try
					{
						Drawable d = c.getPackageManager
						().getApplicationIcon
						(t);
						appIcon.setImageDrawable
						(d);
					}
					catch
					(PackageManager.NameNotFoundException
					e)
					{ View v=null;
						return v;
					}*/

					appIcon.setOnClickListener( new AppClick(t,c));


					return convertView;
				}


			};
			this.setNumColumns(2);
			this.setAdapter(adapter);

        }


	}}


}
