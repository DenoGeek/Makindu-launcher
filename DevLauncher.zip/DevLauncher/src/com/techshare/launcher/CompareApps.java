package com.techshare.launcher;
import android.content.*;
import java.util.*;
import java.lang.String;
import java.lang.*;


public class CompareApps implements
Comparator<AppDetail> {
	private List<AppDetail> apps = new ArrayList<AppDetail>
	();
	Context context;
	public CompareApps(String str,List<AppDetail> apps,
					  Context context) {
		this.apps = apps;
		this.context = context;
		Collections.sort(this.apps, this);
	}
	@Override
	public int compare(AppDetail lhs, AppDetail rhs) {
		// TODO Auto-generated method stub
		return lhs.label.toString().toUpperCase().compareTo
		(rhs.label.toString().toUpperCase());
	}
}
