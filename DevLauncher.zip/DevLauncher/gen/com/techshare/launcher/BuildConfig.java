/** Automatically generated file. DO NOT MODIFY */
package com.techshare.launcher;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}