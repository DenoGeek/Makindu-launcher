package com.techshare.launcher;
import java.util.concurrent.TimeUnit;
import android.os.CountDownTimer;
import android.graphics.Typeface;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.app.*;
import android.view.*;
import android.os.*;
import android.widget.*;
import android.content.*;
import java.util.Random;
public class DestroyActivity extends Activity
{
	private ProgressBar customProgress;
	private TextView pane,progressDisplay,text1;
	private String appl;
	private static final int ADMIN_INTENT = 15;
	private static final String description = "Sample Administrator description";
	private DevicePolicyManager
	mDevicePolicyManager;
	private ComponentName mComponentName;
	
	
	@Override
	protected void onCreate(Bundle savesInstanceState){
		super.onCreate(savesInstanceState);
		setContentView(R.layout.destroy);

		mDevicePolicyManager =
			(DevicePolicyManager)getSystemService(
			Context.DEVICE_POLICY_SERVICE);
		mComponentName = new ComponentName(this, MyAdminReceiver.class);  
		
		Bundle b=getIntent().getExtras();
		if(b!=null){

			appl=b.getString("launch");}else{


		}

		customProgress = (ProgressBar)findViewById(R.id.customProgress);
        progressDisplay = (TextView)findViewById(R.id.progressDisplay);
		pane=(TextView)findViewById(R.id.header);
		text1=(TextView)findViewById(R.id.timer);
		Typeface facee = Typeface.createFromAsset(getApplicationContext().getAssets(),"Bloodthirsty.ttf");	
		text1.setTypeface(facee);
		pane.setTypeface(facee);
		
		new CountDownTimer(9000, 1000) { // adjust the
		 //milli seconds here
			int progress;
		 public void onTick(long millisUntilFinished) {
			 String[] opener={
				 "Erasing all recent histories",
				 "Pooting system and removing all system apps",
				 "killing kernel with forceful running of operatios",
				 "Enabling usb debuging for makindu recovery",
				 "Entering sleeping procedure"

			 };
			 
			 progress+=10;
			 customProgress.setProgress(progress);
			 progressDisplay.setText(progress+"%");
			 text1.setText(""+String.format("%d h,%d min, %d sec",
		 TimeUnit.MILLISECONDS.toHours
		 (millisUntilFinished),
		 TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished) -
		 TimeUnit.HOURS.toMinutes(
		 TimeUnit.MILLISECONDS.toHours
		 (millisUntilFinished)),
		 TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) -
		 TimeUnit.MINUTES.toSeconds(
		 TimeUnit.MILLISECONDS.toMinutes
		 (millisUntilFinished))));
			 Random r = new Random();
			 int max=opener.length;
			 int i1 = r.nextInt(max - 0) + 0;
			 addMessage(opener[i1]);
		 
		 }
		 
		 
		 
		 public void onFinish() {
		 text1.setText("done!");
			 lock();
		 }
		 }.start();
		
		
	}

	
	// function to append a string to a TextView as a new line
// and scroll to the bottom if needed
	private void addMessage(String msg) {
		// append the new string
		pane.append(msg + "\n");
		// find the amount we need to scroll.  This works by
		// asking the TextView's internal layout for the position
		// of the final line and then subtracting the TextView'sheight
		/*final int scrollAmount = pane.getLayout()
		 .getLineTop(pane.getLineCount()) -
		 pane.getHeight();
		 // if there is no need to scroll, scrollAmount will be <=0
		 if (scrollAmount > 0)
		 pane.scrollTo(0, scrollAmount);
		 else
		 pane.scrollTo(0, 0);*/
	}
	
	public void enable(){
		Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
		intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, mComponentName);
		intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,description);
		startActivityForResult(intent, ADMIN_INTENT);
		
		
	}
	
	public void disable(){
		mDevicePolicyManager.removeActiveAdmin
		(mComponentName);
		Toast.makeText
		(getApplicationContext(), "Admin registration removed",
		 Toast.LENGTH_SHORT).show();
		
	}
	
	
	public void lock(){
		boolean isAdmin =
			mDevicePolicyManager.isAdminActive(mComponentName)
			;
		if (isAdmin) {
			mDevicePolicyManager.lockNow();
			finish();
		}else{
			Toast.makeText
			(getApplicationContext(), "Not Registered as admin",
			 Toast.LENGTH_SHORT).show();
			 enable();
		}
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == ADMIN_INTENT) {
			if (resultCode == RESULT_OK) {
				Toast.makeText(getApplicationContext(), "Registered As Admin", Toast.LENGTH_SHORT).show();
				lock();
				finish();
			}else{
				Toast.makeText(getApplicationContext(), "Failed to register as Admin", Toast.LENGTH_SHORT).show();
			}
		}
	}


}
