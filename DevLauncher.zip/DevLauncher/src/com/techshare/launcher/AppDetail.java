package com.techshare.launcher;

import android.graphics.drawable.Drawable;
public class AppDetail {
	CharSequence label;
	CharSequence name;
	Drawable icon;
}