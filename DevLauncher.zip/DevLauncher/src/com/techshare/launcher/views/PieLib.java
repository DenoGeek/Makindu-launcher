package com.techshare.launcher.views;

import android.content.Context;
import android.view.View;
import java.util.*;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.graphics.Typeface;
import android.widget.*;
import com.techshare.launcher.R;
import lecho.lib.hellocharts.listener.PieChartOnValueSelectListener;
import lecho.lib.hellocharts.model.PieChartData;
import lecho.lib.hellocharts.model.SliceValue;
import lecho.lib.hellocharts.util.ChartUtils;
import lecho.lib.hellocharts.view.Chart;
import lecho.lib.hellocharts.view.PieChartView;
import android.sax.*;
import android.os.StatFs;
import java.io.File;
import android.os.Environment;
import java.util.concurrent.*;
import android.os.storage.*;


public class PieLib extends RelativeLayout
{
	private PieChartView chart;
	private PieChartData data;
	private ViewGroup rootView;
	private boolean hasLabels = true;
	private boolean hasLabelsOutside = false;
	private boolean hasCenterCircle = true;
	private boolean hasCenterText1 = false;
	private boolean hasCenterText2 = false;
	private boolean isExploded = false;
	private boolean hasLabelForSelected = false;
	
	public  PieLib(Context context){
		super(context);
		
		
		LayoutInflater inflater = (LayoutInflater) context
			.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		inflater.inflate(R.layout.pie_view, this, true);
		
		
		chart = (PieChartView)this.findViewById(R.id.chart);
		chart.setOnValueTouchListener(new ValueTouchListener());
		
		generateData();
	
		TextView title = (TextView)this.findViewById(R.id.pieviewTextView1);
		title.setText("Storage");
		
		
		this.setBackgroundResource(R.drawable.glas);
	}
	
	private void reset() {
		chart.setCircleFillRatio(1.0f);
		hasLabels = false;
		hasLabelsOutside = false;
		hasCenterCircle = false;
		hasCenterText1 = false;
		hasCenterText2 = false;
		isExploded = false;
		hasLabelForSelected = false;
	}

	private void generateData() {
		
		int dafa[]=memspaces();
		String labels[]={"Free in","used In","Free out","used Out"};
		int numValues;
		if(externalMemoryAvailable()){ numValues = 4;}else{numValues=2;}
		int all=dafa[0]+dafa[1]+dafa[2]+dafa[3];
		List<SliceValue> values = new ArrayList<SliceValue>();
		for (int i = 0; i < numValues; ++i) {
			SliceValue sliceValue = new SliceValue((float)dafa[i], ChartUtils.pickColor());
			sliceValue.setLabel(labels[i]);
			values.add(sliceValue);
		}

		data = new PieChartData(values);
		data.setHasLabels(hasLabels);
		data.setHasLabelsOnlyForSelected(hasLabelForSelected);
		data.setHasLabelsOutside(hasLabelsOutside);
		data.setHasCenterCircle(hasCenterCircle);

		if (isExploded) {
			data.setSlicesSpacing(24);
		}

		if (hasCenterText1) {
			data.setCenterText1("Storage");

			// Get roboto-italic font.
			Typeface tf = Typeface.createFromAsset(getContext().getAssets(), "Roboto-Italic.ttf");
			data.setCenterText1Typeface(tf);

			// Get font size from dimens.xml and convert it to sp(library uses sp values).
			data.setCenterText1FontSize(ChartUtils.px2sp(getResources().getDisplayMetrics().scaledDensity,
														 (int) getResources().getDimension(R.dimen.pie_chart_text1_size)));
		}

		if (hasCenterText2) {
			data.setCenterText2("Charts (Roboto Italic)");

			Typeface tf = Typeface.createFromAsset(getContext().getAssets(), "Roboto-Italic.ttf");

			data.setCenterText2Typeface(tf);
			data.setCenterText2FontSize(ChartUtils.px2sp(getResources().getDisplayMetrics().scaledDensity,
														 (int) getResources().getDimension(R.dimen.pie_chart_text2_size)));
		}

		chart.setPieChartData(data);
	}

	private void explodeChart() {
		isExploded = !isExploded;
		generateData();

	}

	private void toggleLabelsOutside() {
		// has labels have to be true:P
		hasLabelsOutside = !hasLabelsOutside;
		if (hasLabelsOutside) {
			hasLabels = true;
			hasLabelForSelected = false;
			chart.setValueSelectionEnabled(hasLabelForSelected);
		}

		if (hasLabelsOutside) {
			chart.setCircleFillRatio(0.7f);
		} else {
			chart.setCircleFillRatio(1.0f);
		}

		generateData();

	}

	private void toggleLabels() {
		hasLabels = !hasLabels;

		if (hasLabels) {
			hasLabelForSelected = false;
			chart.setValueSelectionEnabled(hasLabelForSelected);

			if (hasLabelsOutside) {
				chart.setCircleFillRatio(0.7f);
			} else {
				chart.setCircleFillRatio(1.0f);
			}
		}

		generateData();
	}

	private void toggleLabelForSelected() {
		hasLabelForSelected = !hasLabelForSelected;

		chart.setValueSelectionEnabled(hasLabelForSelected);

		if (hasLabelForSelected) {
			hasLabels = false;
			hasLabelsOutside = false;

			if (hasLabelsOutside) {
				chart.setCircleFillRatio(0.7f);
			} else {
				chart.setCircleFillRatio(1.0f);
			}
		}

		generateData();
	}

	/**
	 * To animate values you have to change targets values and then call {@link Chart#startDataAnimation()}
	 * method(don't confuse with View.animate()).
	 */
	private void prepareDataAnimation() {
		for (SliceValue value : data.getValues()) {
			value.setTarget((float) Math.random() * 30 + 15);
		}
	}

	private class ValueTouchListener implements PieChartOnValueSelectListener {

		@Override
		public void onValueSelected(int arcIndex, SliceValue value) {
			Toast.makeText(getContext(), "Selected: " + value, Toast.LENGTH_SHORT).show();
		}

		@Override
		public void onValueDeselected() {
			// TODO Auto-generated method stub

		}

	}
	
	public static boolean externalMemoryAvailable() {
        return android.os.Environment.
			getExternalStorageState().equals(
			android.os.Environment.MEDIA_MOUNTED);
    }
	
	private int[] memspaces(){
		int[] mem;
		mem=new int[]{0,0,0,0,0};
		
		//gei internal available
		File path = Environment.getDataDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSize();
        long availableBlocks = stat.getAvailableBlocks();
		mem[0]=(int)(availableBlocks*blockSize);
		
		//get all internal menory
		File pathe =
			Environment.getDataDirectory();
        StatFs state = new StatFs
		(pathe.getPath());
        long blockSizee = stat.getBlockSize();
        long totalBlocks = stat.getBlockCount
		();
		mem[1]=(int)((blockSizee*totalBlocks)-mem[0]);
		
		
		//get available external memory
		if (externalMemoryAvailable()) {
            File patht =
				Environment.getExternalStorageDirectory();
            StatFs statt = new StatFs
			(patht.getPath());
            long blockSizet = stat.getBlockSize();
            long availableBlockst = stat.getAvailableBlocks();
            mem[2]=(int)(blockSizet*availableBlockst);
        } else {
           
        }
		
		//get all external memory
		if (externalMemoryAvailable()) {
            File pathy =
				Environment.getExternalStorageDirectory();
            StatFs staty = new StatFs
			(pathy.getPath());
            long blockSizey = stat.getBlockSize();
            long totalBlocksy = stat.getBlockCount();
            mem[3]=(int)((blockSizey*totalBlocksy)-mem[2]);
        } else {
            
        }
		
		
		return mem;
	}
	
    
}
