package com.techshare.launcher;

import android.app.Activity;
import android.app.ActivityManager.RunningServiceInfo;
import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.*;
import android.view.View;
import android.webkit.*;
import android.widget.*;
import android.graphics.Color;
import android.util.AttributeSet;
import android.view.View.*;
import android.app.*;
import android.animation.*;
import android.view.animation.*;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.os.CountDownTimer;
import android.preference.*;
import com.techshare.launcher.transforms.*;
import android.support.v4.view.ViewPager.PageTransformer;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import java.util.Random;
import android.content.Context;
import com.techshare.launcher.views.InstructView;
import com.techshare.launcher.views.*;
import com.easyandroidanimations.library.*;
public class HomeActivity extends FragmentActivity {
	private ViewPager _mViewPager;
	private HomePagerAdapter _adapter;
	private SlideMenu sm;
	@Override
	protected void onCreate(Bundle
							savedInstanceState) {
		super.onCreate
		(savedInstanceState);
		setContentView(R.layout.home);
		configa();
		
		sm=(SlideMenu)findViewById(R.id.slideMenu);
		sm.setOnSlideStateChangeListener(new SlideMenu.OnSlideStateChangeListener(){
			@Override
			public void onSlideStateChange(int slideState){
				//Sqlite.report(""+slideState,getApplicationContext());
				if(Controler.refreshNeeded(getApplicationContext())){
				//configa();
				}
				if(slideState==SlideMenu.STATE_OPEN_RIGHT){
					if(Controler.menuHelpShown(getApplicationContext())){
						if(!Controler.isMyServiceRunning(InstructView.class,getApplicationContext())){
							
						Intent si=new Intent(getApplication(), InstructView.class);
						si.putExtra("id","4");
						startService(si);
						}
					}
				}
				if(slideState==SlideMenu.STATE_OPEN_LEFT){
					if(Controler.pmenuHelpShown(getApplicationContext())){
						if(!Controler.isMyServiceRunning(InstructView.class,getApplicationContext())){
							
						Intent si=new Intent(getApplication(), InstructView.class);
						si.putExtra("id","6");
						startService(si);
					}}
					
				}
			}
			
			public void onSlideOffsetChange(float offsetPercent){
					
			}
			
		});
		
		
	}
	public void showApps(View v){
		Intent i = new Intent(this,
							  AppListActivity.class);
		startActivity(i);
	}
	
	
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// TODO: Implement this method
		MenuInflater inflater=getMenuInflater();
		inflater.inflate(R.menu.menu, menu);
		
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		// TODO: Implement this method
		switch(item.getItemId()){
			case R.id.own:
				Intent a=new Intent(getApplicationContext(),MainActivity.class);
				startActivity(a);
				break;
				
		case R.id.mng:
				Intent g=new Intent(getApplicationContext(),AppListActivity.class);
				startActivity(g);
			break;
		}
		return super.onOptionsItemSelected(item);
	}
	
	
	private void setUpView(){

    	final PageTransformer[] t={
			new CubeOutTransformer(),
			//new CubeInTransformer(),
			//new StackTransformer(),
			//new AccordionTransformer(),
			//new BackgroundToForegroundTransformer(),
			//new DepthPageTransformer(),
			new FlipHorizontalTransformer(),
			//new FlipVerticalTransformer(),
			//new ForegroundToBackgroundTransformer(),
			//new RotateDownTransformer(),
			////new RotateUpTransformer(),
			new ScaleInOutTransformer(),
			//new StackTransformer(),
			//new TabletTransformer(),
			//new ZoomInTransformer(),
			//new ZoomOutSlideTransformer(),
			//new ZoomOutTranformer()
			
		};
		_mViewPager = (ViewPager) findViewById(R.id.main);
		_adapter = new HomePagerAdapter(getApplicationContext(),getSupportFragmentManager());
		_mViewPager.setAdapter(_adapter);
		_mViewPager.setCurrentItem(1);
		_mViewPager.setOnPageChangeListener(new
			OnPageChangeListener() {
				public void onPageScrollStateChanged
				(int state) {}
				public void onPageScrolled(int position,
										   float positionOffset, int positionOffsetPixels) {}
				public void onPageSelected(int position) {
					// Check if this is the page you want.
					_mViewPager.setPageTransformer( true ,t[new Random().nextInt
												   (t.length) ]);
				
							
					switch(position){
						case 0:
							
							break;
						case 1:
							if(Controler.padlockShown(getApplicationContext())){
								if(!Controler.isMyServiceRunning(InstructView.class,getApplicationContext())){
									
								Intent si=new Intent(getApplication(), InstructView.class);
								si.putExtra("id","1");
								startService(si);
							}}
							break;
						case 2:
							if(Controler.homeHelpShown(getApplicationContext())){
								if(!Controler.isMyServiceRunning(InstructView.class,getApplicationContext())){
									
								Intent si=new Intent(getApplication(), InstructView.class);
								si.putExtra("id","2");
								startService(si);
							}}
							break;
						case 3:
							if(Controler.hackHelpShown(getApplicationContext())){
								if(!Controler.isMyServiceRunning(InstructView.class,getApplicationContext())){
									
								Intent si=new Intent(getApplication(), InstructView.class);
								si.putExtra("id","3");
								startService(si);
							}}
							break;
							
					}
				}
			});
		
    }
	
	
	private boolean isMyServiceRunning
	(Class<?> serviceClass) {
		ActivityManager manager = (ActivityManager) getSystemService
		(Context.ACTIVITY_SERVICE);
		for (RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
			if (serviceClass.getName().equals
				(service.service.getClassName())) {
				return true;
			}
		}
		return false;
	}
	
	
	public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            //do your work
			
			 if(isMyServiceRunning(MenuView.class)){
				 Intent si=new Intent(getApplication(), MenuView.class);
				 si.putExtra("id","0");
				 stopService(si);
			 }else{
			Intent si=new Intent(getApplication(), MenuView.class);
			si.putExtra("id","0");
			startService(si);
			}
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
	
	
	
	public void configa(){
		
		Sqlite.initDatabase(getApplicationContext());
		Sqlite.InsertBasics(getApplicationContext());
		AttributeSet attrs=null;

   		//startService(new Intent(getApplication(), ChatHeadService.class));

		RelativeLayout sm=(RelativeLayout)findViewById(R.id.smenu);
		sm.removeAllViews();
		




		RelativeLayout pm=(RelativeLayout)findViewById(R.id.pmenu);
		pm.removeAllViews();
		ProfileView p=new ProfileView(getApplicationContext(),attrs);
		pm.addView(p);

		setUpView();
		
		PreferenceManager.getDefaultSharedPreferences(getApplicationContext())
			.edit().putString("refresh",null).commit();
		
		
		
	}
	
	@Override
	protected void onResume() {
		super .onResume();
		//Log . d (msg , "The onResume() event" );
		sm.close(false);
		//new PuffInAnimation(sm);
		refresh();
		
		//Sqlite.report("resumed",getApplicationContext());
	}
/** Called when another activity is taking focus . */
	@Override
		protected void onPause() {
		super .onPause();
			if(isMyServiceRunning(MenuView.class)){
				Intent si=new Intent(getApplication(), MenuView.class);
				si.putExtra("id","0");
				stopService(si);
			}
		
		
			if(isMyServiceRunning(InstructView.class)){
				Intent si=new Intent(getApplication(), InstructView.class);
				si.putExtra("id","0");
				stopService(si);
			}
			//Sqlite.report("paused",getApplicationContext());
		//Log . d (msg , "The onPause() event" );
	}
	
	
	
	public void refresh(){
		
		if(Controler.refreshNeeded(getApplicationContext())){
			_adapter.notifyDataSetChanged();
			//Sqlite.report("Refreshed",getApplicationContext());
			AttributeSet attrs=null;
			RelativeLayout sm=(RelativeLayout)findViewById(R.id.smenu);
			sm.removeAllViews();
			


			RelativeLayout pm=(RelativeLayout)findViewById(R.id.pmenu);
			pm.removeAllViews();
			ProfileView p=new ProfileView(getApplicationContext(),attrs);
			pm.addView(p);
			
		}
	}
	
	
}
