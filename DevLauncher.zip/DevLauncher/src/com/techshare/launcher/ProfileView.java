package com.techshare.launcher;

import android.content.Context;
import android.content.Intent;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.LinearLayout;
import android.widget.GridView;
import android.widget.TextView;
import android.graphics.*;
import android.graphics.Paint.*;
import android.graphics.drawable.shapes.*;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.Drawable;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.SystemClock;
import java.util.Random;
import android.view.WindowManager;
import android.content.ContentResolver;
import android.provider.ContactsContract;
import 
android.text.method.ScrollingMovementMethod;
import android.util.*;
import android.provider.CallLog;
import android.database.Cursor;
import android.content.Context;
import java.util.Date;
import android.preference.*;
import android.widget.Button;
import com.techshare.launcher.views.MenuView;
public class ProfileView extends RelativeLayout
{

	private String title,footer;
	private int topCol;
	private String[] calls;



	
    private ProgressBar customProgress;
    private TextView progressDisplay;
	private TextView pane,name,number;
private ImageView ico;


	public ProfileView(final Context context, AttributeSet attrs){
		super(context, attrs);
		//paint object for drawing in onDraw


		//at this point try fetching custom attributes
		TypedArray a = context.getTheme().obtainStyledAttributes
		(attrs,
		 R.styleable.CustomGrid, 0, 0);


		try {
			//get the text and colors specified using thenames in attrs.xml
			title = a.getString(R.styleable.CustomGrid_gridTitle);
			footer = a.getString(R.styleable.CustomGrid_gridFooter);//0 is default
			topCol = a.getInteger(R.styleable.CustomGrid_gridTitleBg, 0);
		} finally {
			a.recycle();
		}
		
		
		LayoutInflater inflater = (LayoutInflater) context
			.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		inflater.inflate(R.layout.profile, this, true);
		
		
		 ico=(ImageView)getChildAt(0);
		
		ico.setOnClickListener(new OnClickListener(){
			 @Override
			 public void onClick(View v){
				 
				 
					 Intent si=new Intent(context, MenuView.class);
					 si.putExtra("id","0");
					 si.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					 context.startService(si);
				 
			 }
			 
		 });
		 
		/* String user=PreferenceManager.getDefaultSharedPreferences(context)
.getString("user", "The hacker grill");
		String phone=PreferenceManager.getDefaultSharedPreferences(context)
			.getString("phone", "911");*/
		 name=(TextView)getChildAt(1);
		
		 number=(TextView)getChildAt(2);
		//name.setText(user);
		//number.setText(phone);
		
		 //getSelfSimNumber(context);
		 
		ImageView sico=(ImageView)getChildAt(3);

		sico.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View v){
					Intent y=new Intent(context,SettingsActivity.class);
					y.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					context.startActivity(y);
					
				}
		 
		});
		WindowManager windowManager = (WindowManager)
			context
			.getSystemService(Context.WINDOW_SERVICE);

		int width=windowManager.getDefaultDisplay()
			.getWidth()/10*7;
		int height=windowManager.getDefaultDisplay()
			.getHeight()/10*5;
		LinearLayout.LayoutParams layoutParams = new
			LinearLayout.LayoutParams(		LinearLayout.LayoutParams.FILL_PARENT,
									  LinearLayout.LayoutParams.WRAP_CONTENT);
		layoutParams.setMargins(15, 6, 15, 10);


		RelativeLayout.LayoutParams p = new
			RelativeLayout.LayoutParams
		(ViewGroup.LayoutParams.WRAP_CONTENT,
		 ViewGroup.LayoutParams.WRAP_CONTENT);
		p.addRule(RelativeLayout.BELOW, R.id.icon);
	
		
		


		FavsGrid f=new FavsGrid(context,attrs);
		f.setLayoutParams(p);
		this.addView(f);
		
		//this.setPadding(5,5,5,5);
		this.setLayoutParams(layoutParams);
		
	}
	
	public void ock(View v){
		 Intent i = new Intent(getContext(),
		 AppListActivity.class);
		 getContext().startActivity(i);
	}
	

	
	private void getSelfSimNumber(Context co) {
        ContentResolver cr = co.getContentResolver();
        Cursor cur = cr.query
		(ContactsContract.Contacts.CONTENT_URI,
		 null, null, null, null);
        if (cur.getCount() > 0) {
            while (cur.moveToNext()) {
				String id = cur.getString(cur.getColumnIndex
										  (ContactsContract.Contacts._ID));
				String name = cur.getString(cur.getColumnIndex
											(ContactsContract.Contacts.DISPLAY_NAME));
				/*if (Integer.parseInt(cur.getString(
										 cur.getColumnIndex
										 (ContactsContract.Contacts.HAS_PHONE_NUMBER))) > 0)
				{*/
				if(id.equals("1")){
					Cursor pCur = cr.query(
						ContactsContract.CommonDataKinds.Phone.
						CONTENT_URI,
						null,
						ContactsContract.CommonDataKinds.Phone.CONTACT_ID
						+" = ?",
						new String[]{id}, null);
					while (pCur.moveToNext()) {
						String phoneNo = pCur.getString
						(pCur.getColumnIndex
						 (ContactsContract.CommonDataKinds.Phone.NUMBER));
						Toast.makeText(co,
									   "Name: " + name + ",  Phone No: " + phoneNo,
									   Toast.LENGTH_SHORT).show();
					}
                    pCur.close();
                }
            }
		}
    }
	
	
	}
		
