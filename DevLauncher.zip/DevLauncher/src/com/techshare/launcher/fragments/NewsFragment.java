package com.techshare.launcher.fragments;
import android.view.*;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.os.*;
import android.widget.*;
import android.graphics.Typeface;
import com.techshare.launcher.R;
import com.techshare.launcher.views.ButtonWithIcons;
import android.content.Context;
import com.techshare.launcher.Controler;

import com.easyandroidanimations.library.PuffOutAnimation;
import com.easyandroidanimations.library.Animation;
import com.easyandroidanimations.library.AnimationListener;
import com.easyandroidanimations.library.BounceAnimation;
import com.easyandroidanimations.library.FlipVerticalAnimation;
import java.util.*;
import android.text.Layout;
import com.techshare.launcher.Sqlite;
import android.database.*;
import android.database.sqlite.*;
import android.content.*;
import com.koushikdutta.ion.Ion;
import com.koushikdutta.async.future.Future;
import com.koushikdutta.async.future.FutureCallback;
import java.net.*;
import org.json.*;
import android.view.View.*;
import android.net.Uri;
public class NewsFragment extends Fragment
{
	private ListView newslist;
	private NewsAdapter adapt;
	Typeface bloody,nice;
	private ProgressBar p;
	private String baseurl;
	private ArrayList<News> allnews;
	public static Fragment newInstance(Context context) {
		NewsFragment f = new NewsFragment();	

		return f;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
		ViewGroup root = (ViewGroup) inflater.inflate(R.layout.news_fragment, null);		
		
		newslist=(ListView)root.findViewById(R.id.newsfragmentListView1);
		bloody = Typeface.createFromAsset(getActivity().getApplicationContext().getAssets(),"Bloodthirsty.ttf");	
	    nice = Typeface.createFromAsset(getActivity().getApplicationContext().getAssets(),"fonts/Walkway_Bold.ttf");
		
		baseurl="http://makindu.techshare.co.ke/";
		
		TextView top=(TextView)root.findViewById(R.id.newsfragmentTextView1);
		top.setTypeface(bloody);
		 p=(ProgressBar)root.findViewById(R.id.newsfragmentProgressBar1);
		ImageView tp=(ImageView)root.findViewById(R.id.newsfragmentImageView2);
		tp.setOnClickListener(new OnClickListener(){
			
			@Override
			public void onClick(View v){
				configure(getActivity().getApplicationContext());
			}
		});
		configure(getActivity().getApplicationContext());
		return root;
		}
	//configure function

	public void configure(Context context){
		//allnews= loadNews(context);
		loadNews(getActivity().getApplicationContext());
		
		
	}	
	//data model for the news
	public class News{
		String image;
		String text;
		String url;
		String views;
	}
	
	
	private void loadNews(final Context c){
		p.setVisibility(View.VISIBLE);
		
		
		Ion. with(c)
			.load(baseurl+"apinews.php")
			.asString()
			.setCallback( new FutureCallback< String >() {
				@Override
				public void onCompleted (Exception e, String result) {
					// do stuff with the result or error
					//Sqlite.report(result,c);
					p.setVisibility(View.GONE);
					if(e==null){
					if(Controler.isOnline(c)){
						
					allnews=convertNews(c,result);}else{
						
						allnews=offlineNews(c);
					}
					}else{
					allnews=offlineNews(c);
					}
					adapt=new NewsAdapter(c,allnews);
					newslist.setAdapter(adapt);
					}
					});
		
	}
	
	
	private class NewsAdapter extends ArrayAdapter<String> {
		private final Context context;
		private final ArrayList<News> values;
		public NewsAdapter(Context context, ArrayList<News>
								values) {
			super (context, R.layout.news_fragment_row, values);
			this .context = context;
			this .values = values;
		}
		@Override
		public View getView(final int position, View convertView,
							ViewGroup parent) {
			LayoutInflater inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View rowView = inflater.inflate(R.layout.news_fragment_row,parent, false);
			
			final TextView over=(TextView)rowView.findViewById(R.id.newsfragmentrowTextView2);
			final TextView more=(TextView)rowView.findViewById(R.id.newsfragmentrowTextView1);
			final ImageView re=(ImageView)rowView.findViewById(R.id.newsfragmentrowImageView1);
			final TextView mo=(TextView)rowView.findViewById(R.id.newsfragmentrowTextView3);
			final ImageView open=(ImageView)rowView.findViewById(R.id.newsfragmentrowImageView2);
			over.setTypeface(nice);
			more.setTypeface(nice);
			mo.setTypeface(nice);
			
			over.setText(values.get(position).text);
			//This part transfers overflow yext
			ViewTreeObserver vto = over.getViewTreeObserver();
			vto.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
					@Override
					public void onGlobalLayout() {
						Layout l = over.getLayout();
						int height = over.getHeight();
						int scrollY = over.getScrollY();
						/**
						 * Key part
						 */
						int lineCount = l.getLineForVertical(height + scrollY);
						int start = l.getLineStart(0);
						int end = l.getLineEnd
						(lineCount - 1);
						/**
						 * Cut string
						 */
						final String s = over.getText().toString
						().substring(start, end);
						
						//over.setText(s);
						String[] h=values.get(position).text.split(" ");
						int y=s.split(" ").length;
						StringBuilder sb=new StringBuilder();
						for(int i=y;i<h.length-2;i++){
							sb.append(h[i]);
						}
						
						more.setText(sb.toString());
						open.setOnClickListener(new OnClickListener(){
							@Override
							public void onClick(View v){
								Intent browserIntent = new Intent
								(Intent.ACTION_VIEW, Uri.parse(baseurl+"redirect.php?url="+values.get(position).url));
								browserIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
								getActivity().startActivity(browserIntent);
								
								
							}
							
						});
						
					}
				}
			);
			
			Ion.with(re).placeholder(getActivity().getResources().getDrawable(R.drawable.loading))
			.centerCrop()
			.load(baseurl+"images/"+values.get(position).image);
			
			
			
			mo.setText(values.get(position).views+" ,Likes");
			return rowView;
			
			}
			
			
			
		}
		
		
	private ArrayList<News> convertNews(Context c,String data){

		
		ArrayList<News> nw=new ArrayList<News>();
		News nn=new News();

		
		String dbName = "makindu";
		String tableName = "news";
		SQLiteDatabase myDb = null;
		try{
			myDb=  c.openOrCreateDatabase(dbName, c.MODE_WORLD_WRITEABLE, null);
			myDb.execSQL( "DELETE FROM " + tableName); 	
			//report("Removed from dock",c);
		}catch (SQLiteException se ) {
			Sqlite.report("Error removing news from db",c);
		} finally {
		}
		
		JSONObject jObj;
		JSONArray dataJsonArr = null;
		if(data!=null){
			try {
				jObj = new JSONObject(data);
				try{
					dataJsonArr = jObj.getJSONArray( "news" );
					// loop through all users
					for ( int i = 0; i < dataJsonArr.length(); i++) {
						JSONObject j = dataJsonArr.getJSONObject(i);						
						// Storing each json item in variable

						nn=new News();
						String im = j.getString( "image" );
						String nw8 = j.getString( "news" );
						String li = j.getString( "likes" );
						String ln = j.getString( "link" );
						nn.image=im;
						nn.text=nw8;
						nn.url=ln;
						nn.views=li;
						Sqlite.insertNews(c,im,nw8,li,ln);
						nw.add(nn);
					}
				}catch(JSONException h){
					//Sqlite.report("error retrieving data",c);
				}
			} catch (JSONException k) {
				//Sqlite.report("Error parsing data " + k.toString(),c);
			}
		}
		
			
			
			/*
			
			
			*/
			
			
		
		return nw;
	}
	
	
	private ArrayList<News> offlineNews(Context c){

		
		

		ArrayList<News> nw=new ArrayList<News>();
		News nn=new News();
		
		String dbName = "makindu";
		String tableName = "news";
		SQLiteDatabase myDb = null;
		//check whether ths array exists in database
		try {


			//Instantiate sampleDB object
			myDb =  c.openOrCreateDatabase(dbName, c.MODE_WORLD_WRITEABLE, null);
			//Create Cursor object to read versions from the table
			Cursor a = myDb.rawQuery("SELECT * FROM "+tableName, null);
			//If Cursor is valid
			if (a != null ) {
				//Move cursor to first row
				if  (a.moveToFirst()) {
					do {
						//Get version from Cursor
						nn=new News();

						String f = a.getString(a.getColumnIndex("image"));
						String g = a.getString(a.getColumnIndex("news"));
						String h = a.getString(a.getColumnIndex("likes"));
						String i = a.getString(a.getColumnIndex("link"));

						nn.image=f;
						nn.text=g;
						nn.url=i;
						nn.views=h;
						nw.add(nn);


					}while (a.moveToNext()); //Move to next row
				} 
			}
		} catch (SQLiteException se ) {
			//Server.newload(c);
			Sqlite.report("Error loafing news",c);
		} finally {
			if (myDb== null) {
				//sampleDB.execSQL("DELETE FROM " + tableName);
				//sampleDB.close();
			}
		}
		return nw;
		}
		
}
