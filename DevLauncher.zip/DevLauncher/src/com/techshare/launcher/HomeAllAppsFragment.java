package com.techshare.launcher;

import android.support.v4.app.Fragment;
import android.content.Context;
import android.view.*;
import android.os.Bundle;
import android.widget.*;
import android.util.*;


public class HomeAllAppsFragment extends Fragment
{
	
	public static Fragment newInstance(Context context) {
		HomeAllAppsFragment f = new HomeAllAppsFragment();	

		return f;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
		ViewGroup root = (ViewGroup) inflater.inflate(R.layout.home_all_apps, null);		
		LinearLayout sm=(LinearLayout)root.findViewById(R.id.homeallappsLinearLayout1);
		
		AttributeSet attrs=null;
		AppsGrid al=new AppsGrid(getActivity().getApplicationContext(),attrs);
		sm.addView(al);
		
		return root;
		}
}
