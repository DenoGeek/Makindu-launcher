package com.techshare.launcher;

import android.support.v4.app.FragmentActivity;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import com.techshare.launcher.fragments.*;
import android.os.Bundle;
import java.util.*;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.AdapterView.*;
import android.view.*;
import android.widget.*;
import com.techshare.launcher.views.InstructView;
import android.content.Intent;
import android.support.v4.widget.DrawerLayout;
import com.techshare.launcher.views.FloatingBrowser;

public class SettingsActivity extends FragmentActivity
{
	private ListView mDrawerList;
	@Override
	protected void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.settings_activity);
		
		if(Controler.settingsShown(getApplicationContext())){
		Intent si=new Intent(getApplication(), InstructView.class);
		si.putExtra("id","0");
		startService(si);
		}
		
		
		LinearLayout l=(LinearLayout)findViewById(R.id.settings_activityLinearLayout);
		final DrawerLayout dr=(DrawerLayout)findViewById(R.id.drawer_layout);
		dr.openDrawer(dr.getChildAt(1));
		
		
		l.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				dr.closeDrawer(dr.getChildAt(1));
			}
			
		});
		//set up side list
		String[] menuTitles={"Hack views", "Home Apps", "Dock Apps", "Customize","Refresh","Browser"};
		mDrawerList = ( ListView) findViewById( R.id. drawer_content);
		String[] from={"name","pic"}; int[] to={R.id.it, R.id.im} ;

		int[] pics={R.drawable.cmd,R.drawable.home,R.drawable.dock,R.drawable.cmd,R.drawable.update,R.drawable.net,R.drawable.net};
		List<HashMap<String,String>> j=new ArrayList<HashMap<String,String>>();

		for (int i=0;i<6;i++){
			HashMap<String,String> hm=new  HashMap<String,String>();

			hm.put("name", menuTitles[i]);
			hm.put("pic", Integer.toString(pics[i]));
			j.add(hm);
		}

		SimpleAdapter smp=new SimpleAdapter(this,j,R.layout.settings_activity_list_item,from,to);

		mDrawerList .setAdapter (smp);
		mDrawerList.setOnItemClickListener(new clicka());
		
		ConfigureDock webfra = new ConfigureDock();
		Bundle bundl = new Bundle();
		bundl.putString("web", null);
		webfra.setArguments(bundl);
		FragmentTransaction f = getSupportFragmentManager()
			.beginTransaction();
		f.setCustomAnimations(R.anim.slideleft,
							  R.anim.slideright);
		f.replace(R.id.configure_appFrameLayout, webfra,"fragment");
		// Start the animated transition.
		f.commit();
	}
	
	
	private class clicka implements OnItemClickListener
	{

		@Override
		public void onItemClick(AdapterView<?> p1, View p2, int p3, long p4)
		{
			// TODO: Implement this method
			final DrawerLayout dr=(DrawerLayout)findViewById(R.id.drawer_layout);
			
			switch(p3){
				
				case 0:
					ConfigureHacks webfrag = new ConfigureHacks();
					Bundle bundle = new Bundle();
					bundle.putString("web", null);
					webfrag.setArguments(bundle);
					FragmentTransaction ft = getSupportFragmentManager()
						.beginTransaction();
					ft.setCustomAnimations(R.anim.slideleft,
										   R.anim.slideright);
					ft.replace(R.id.configure_appFrameLayout, webfrag,"fragment");
					// Start the animated transition.
					ft.commit();
					
				break;
				
				case 1:
					ConfigureHome webfragg = new ConfigureHome();
					Bundle bundlee = new Bundle();
					bundlee.putString("web", null);
					webfragg.setArguments(bundlee);
					FragmentTransaction ftt = getSupportFragmentManager()
						.beginTransaction();
					ftt.setCustomAnimations(R.anim.slideleft,
										   R.anim.slideright);
					ftt.replace(R.id.configure_appFrameLayout, webfragg,"fragment");
					// Start the animated transition.
					ftt.commit();
					break;
					
				case 2:
					ConfigureDock webfra = new ConfigureDock();
					Bundle bundl = new Bundle();
					bundl.putString("web", null);
					webfra.setArguments(bundl);
					FragmentTransaction f = getSupportFragmentManager()
						.beginTransaction();
					f.setCustomAnimations(R.anim.slideleft,
										   R.anim.slideright);
					f.replace(R.id.configure_appFrameLayout, webfra,"fragment");
					// Start the animated transition.
					f.commit();
					break;
					
				case 3:
					ConfigureCustoms webfr = new ConfigureCustoms();
					Bundle bund = new Bundle();
					bund.putString("web", null);
					webfr.setArguments(bund);
					FragmentTransaction fit = getSupportFragmentManager()
						.beginTransaction();
					fit.setCustomAnimations(R.anim.slideleft,
										   R.anim.slideright);
					fit.replace(R.id.configure_appFrameLayout, webfr,"fragment");
					// Start the animated transition.
					fit.commit();
					break;
				case 4:
					int pid = android.os.Process.myPid();
					android.os.Process.killProcess(pid);
					Toast.makeText(getApplicationContext(),"Restarting",Toast.LENGTH_SHORT).show();
					Intent intent = new Intent(Intent.ACTION_MAIN);
					intent.addCategory(Intent.CATEGORY_HOME);
					getApplicationContext().startActivity(intent);

					break;
				

				case 5:
					startService(new Intent(getApplication(), FloatingBrowser.class));
					break;
					
					
					
				
			}
		}
	
	
	}
	
	@Override
	protected void onPause() {
		super .onPause();
		//Sqlite.report("paused",getApplicationContext());
		//Log . d (msg , "The onPause() event" );
		
		if(Controler.isMyServiceRunning(InstructView.class,getApplicationContext())){
			Intent si=new Intent(getApplication(), InstructView.class);
			si.putExtra("id","0");
			stopService(si);
		}
	}
	

}
