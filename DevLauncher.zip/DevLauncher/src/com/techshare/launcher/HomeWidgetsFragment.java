package com.techshare.launcher;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.*;
import android.util.AttributeSet;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.*;
import android.content.Context;
import android.content.Intent;
import android.webkit.*;
import android.graphics.Color;
import android.database.*;
import android.database.sqlite.*;
import android.widget.LinearLayout.*;
import android.os.Handler;
import android.graphics.PointF;
import android.preference.*;
import java.util.*;
import android.net.Uri;
import android.support.v4.view.*;

import com.easyandroidanimations.library.Animation;
import com.easyandroidanimations.library.AnimationListener;
import android.graphics.Point;
import com.easyandroidanimations.library.PathAnimation;
import com.easyandroidanimations.library.ExplodeAnimation;

public class HomeWidgetsFragment extends Fragment
{
	private ImageView wanna;
	private ViewPager mainpager;
	FrameLayout main;
	private List<Stored> all;
	public static Fragment newInstance(Context context) {
		HomeWidgetsFragment f = new HomeWidgetsFragment();	

		return f;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
		ViewGroup root = (ViewGroup) inflater.inflate(R.layout.widgets_fragment, null);		
		main=(FrameLayout)root.findViewById(R.id.apps_frame);
		loadViews(getActivity().getApplicationContext());
		mainpager=(ViewPager)getActivity().findViewById(R.id.main);
		wanna=new ImageView(getActivity().getApplicationContext());
		FrameLayout.LayoutParams wanaParams = new
			FrameLayout.LayoutParams(100,100);
			wanaParams.gravity=Gravity.BOTTOM|Gravity.RIGHT;
		if(iWannaMove(getActivity().getApplicationContext())){
			wanna.setImageDrawable(getActivity().getApplicationContext().getResources().getDrawable(R.drawable.open));

		}else{
			wanna.setImageDrawable(getActivity().getApplicationContext().getResources().getDrawable(R.drawable.close));

		}
			wanna.setLayoutParams(wanaParams);
			main.addView(wanna);
			wanna.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View v){
					locker();
					if(iWannaMove(getActivity().getApplicationContext())){
						PreferenceManager.getDefaultSharedPreferences(getActivity().getApplicationContext())
							.edit().putString("lockwid",null).commit();
						wanna.setImageDrawable(getActivity().getApplicationContext().getResources().getDrawable(R.drawable.close));
						
					}else{
						PreferenceManager.getDefaultSharedPreferences(getActivity().getApplicationContext())
							.edit().putString("lockwid","Done").commit();
						wanna.setImageDrawable(getActivity().getApplicationContext().getResources().getDrawable(R.drawable.open));
						
					}
				}
			});
		return root;
		}
	
	public void loadViews(Context cc){
		main.removeAllViews();
		all=new ArrayList<Stored>();
		String dbName = "makindu";
		String tableApps="apps";
		SQLiteDatabase myDb = null;
		try{
			myDb =  cc.openOrCreateDatabase(dbName,Context. MODE_PRIVATE, null);

			Cursor c = myDb.rawQuery("SELECT * FROM "+tableApps+" WHERE screen='1' ORDER BY id desc", null);
        	//If Cursor is valid
			int code=0;
        	if (c != null ) {
        		//Move cursor to first row
        		if  (c.moveToFirst()) {
        			do {
        				//Get version from Cursor
        				String name = c.getString(c.getColumnIndex("name"));
						String pname = c.getString(c.getColumnIndex("pname"));
						String xcor = c.getString(c.getColumnIndex("xcor"));
						String ycor= c.getString(c.getColumnIndex("ycor"));
						createView(cc,name,pname,xcor,ycor,code);
						Stored f=new Stored();
						f.setName(pname);
						f.setLabel(name);
						all.add(f);
						code++;
					}while (c.moveToNext()); //Move to next row
        		} 
        	}

		}catch (SQLiteException se ) {
			Sqlite.report("Couldnt Load views data",cc);
		} finally {

		}


	}


	public void createView(Context c,String name,String pname,String xcor,String ycor,int code){


		AttributeSet attrs=null;

		//The layout vimoda parts
		WindowManager windowManager = (WindowManager)
			getActivity().getApplicationContext()
			.getSystemService(Context.WINDOW_SERVICE);

		int width=windowManager.getDefaultDisplay()
			.getWidth()/10*6;
		int height=windowManager.getDefaultDisplay()
			.getHeight()/10*5;	
		FrameLayout.LayoutParams layoutParams = new
			FrameLayout.LayoutParams(100,100);
		layoutParams.gravity = Gravity.TOP;
		layoutParams.setMargins(Sqlite.inTise(xcor),Sqlite.inTise(ycor),0,0);
		
			
			WidgetApp f=new WidgetApp(c,name,pname);
		    
			f.setTag(code);
			f.setOnTouchListener(new Mover());
			f.setLayoutParams(layoutParams);
			main.addView(f);
			
			}
		
	private class Mover implements OnTouchListener{
		PointF DownPT = new PointF(); // RecordMouse Position When Pressed Down
		PointF StartPT = new PointF(); // Record StartPosition of 'img'
		WindowManager windowManager = (WindowManager)
		getActivity().getApplicationContext()
		.getSystemService(Context.WINDOW_SERVICE);

		int width=windowManager.getDefaultDisplay()
		.getWidth()-50;
		int page=1;
		@Override
		public boolean onTouch(final View v, MotionEvent
							   event)
		{
			int eid = event.getAction();
			switch (eid)
			{
				case MotionEvent.ACTION_MOVE :
					
					
					if(iWannaMove(getActivity().getApplicationContext())){
					PointF mv = new PointF( event.getX() -
										   DownPT.x, event.getY() - DownPT.y);
					v.setX((int)(StartPT.x+mv.x));
					v.setY((int)(StartPT.y+mv.y));
					StartPT = new PointF( v.getX(),
										 v.getY() );
										 
					//now handle someone moving an app too close to the margin
					if(v.getX()>width){
						int tag=Sqlite.inTise(v.getTag().toString());
						String t=all.get(tag).label;
						String n=all.get(tag).name;
						Sqlite.updateScreen(getActivity().getApplicationContext(),t,50,(int)v.getY(),2);
						//Sqlite.report("Updated"+v.getX(),getActivity());
						
						page=2;
						
						
					}
										 }
					break;
				case MotionEvent.ACTION_DOWN :
					DownPT.x = event.getX();
					DownPT.y = event.getY();
					StartPT = new PointF( v.getX(),
										 v.getY() );
					break;
				case MotionEvent.ACTION_UP :
					// Nothing have to do
					int tag=Sqlite.inTise(v.getTag().toString());
					String t=all.get(tag).label;
					String n=all.get(tag).name;
					if(iWannaMove(getActivity().getApplicationContext())){
						if(!(v.getX()>width)){
							update(getActivity().getApplicationContext(),t,(int)v.getX(),(int)v.getY());
						}
					    else{
						
							ArrayList<Point> points = new ArrayList<>();
							points.add(new Point(0, 100));
							points.add(new Point(25, 0));
							points.add(new Point(50, 50));
							points.add(new Point(75, 0));
							points.add(new Point(100, 100));
							points.add(new Point(0, 100));
							points.add(new Point(50, 50));
							new PathAnimation(v).setPoints(points).setDuration(2000)
								.setListener(new AnimationListener() {

									@Override
									public void onAnimationEnd(Animation animation) {
										
												mainpager.getAdapter().notifyDataSetChanged();
												mainpager.setCurrentItem(page,true);
												
										
										
										
									}
								}).animate();
							
						}
					}else{
						Intent LaunchIntent = getActivity().getApplicationContext().getPackageManager()
							.getLaunchIntentForPackage(n);
						LaunchIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
						getActivity().getApplicationContext().startActivity( LaunchIntent );
						
					}
					break;
				default :
					break;
			}
			return true;
		}


	};



	public void update(final Context c,String tag,int xcor,int ycor){
		String dbName = "makindu";
		String tableViews="apps";
		SQLiteDatabase myDb = null;
		try{
			myDb =  c.openOrCreateDatabase(dbName, Context.MODE_PRIVATE, null);

			myDb.execSQL( "UPDATE " + tableViews + " SET xcor = '"+xcor+"' WHERE name='"+tag+"'" ); 		
			myDb.execSQL( "UPDATE " + tableViews + " SET ycor = '"+ycor+"' WHERE name='"+tag+"'" ); 		

		}catch (SQLiteException se ) {
        	Toast.makeText(c, "Couldn't update into databasedatabase", Toast.LENGTH_LONG).show();
        } finally {
        	if (myDb != null) {
				//Sqlite.report("updated",c);
			}
		}

	}
	
	
	

	public static boolean iWannaMove(Context c){
		boolean a=true;

		String check=PreferenceManager.getDefaultSharedPreferences(c)
			.getString("lockwid", null);
		if(check!=null){}else{
			a=false;
		}
		return a;
	}
	
	private class Stored{
		private String label;
		private String name;
		
		public String getLabel(){
			return label;
		}
		
		public String getName(){
			return name;
		}
		
		public void setLabel(String s){
			label=s;
		}
		public void setName(String s){
			name=s;
		}
	}
	
	public void locker(){
		if(Controler.isNotLocked(getActivity().getApplicationContext())){
			PreferenceManager.getDefaultSharedPreferences(getActivity().getApplicationContext())
				.edit().putString("lock","done").commit();

		}else{
			PreferenceManager.getDefaultSharedPreferences(getActivity().getApplicationContext())
				.edit().putString("lock",null).commit();

		}
	
	
	}
			
}
