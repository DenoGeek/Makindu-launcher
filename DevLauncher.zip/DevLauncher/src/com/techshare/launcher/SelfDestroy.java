package com.techshare.launcher;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.LinearLayout;
import android.widget.Button; 
import android.widget.TextView;
import android.graphics.*;
import android.content.Intent;
import android.graphics.Paint.*;
import android.graphics.drawable.shapes.*;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.Drawable;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.SystemClock;
import java.util.Random;
import android.view.WindowManager;
import android.content.ContentResolver;
import android.provider.ContactsContract;
import 
android.text.method.ScrollingMovementMethod;
import android.util.*;
import android.provider.CallLog;
import android.database.Cursor;
import android.content.Context;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import android.os.CountDownTimer;
public class SelfDestroy extends RelativeLayout
{

	private String title,footer;
	private int topCol;
	private String[] calls;
    private Button bhk;



	TextView text1;
	private static final String FORMAT = "%02d:%02d:%02d";
	int seconds , minutes;


	public SelfDestroy(final Context context, AttributeSet attrs){
		super(context, attrs);
		//at this point try fetching custom attributes
		TypedArray a = context.getTheme().obtainStyledAttributes
		(attrs,
		 R.styleable.CustomGrid, 0, 0);
		try {
			//get the text and colors specified using thenames in attrs.xml
			title = a.getString(R.styleable.CustomGrid_gridTitle);
			footer = a.getString(R.styleable.CustomGrid_gridFooter);//0 is default
			topCol = a.getInteger(R.styleable.CustomGrid_gridTitleBg, 0);
		} finally {
			a.recycle();
		}
	
		LayoutInflater inflater = (LayoutInflater) context
			.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		inflater.inflate(R.layout.destroybtn, this, true);
		
		TextView pane=(TextView)getChildAt(0);
		if(Controler.pimpColor(context)!=null){
			if(Controler.isColor(Controler.pimpColor(context))){
				pane.setBackgroundColor(Color.parseColor(Controler.pimpColor(context)));
			}
		}
		Typeface bloody = Typeface.createFromAsset(context.getAssets(),"Bloodthirsty.ttf");
		pane.setTypeface(bloody);
		
		pane.setOnClickListener(new OnClickListener(){
			
			@Override
			public void onClick(View v){
				Intent g=new Intent(context,DestroyActivity.class);
				g.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				context.startActivity(g);
			}
		});
		this.setBackground(getResources().getDrawable(R.drawable.glas));
	}

	}
