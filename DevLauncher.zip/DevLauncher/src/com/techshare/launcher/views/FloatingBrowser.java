package com.techshare.launcher.views;



import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.view.*;
import android.content.Context;
import com.techshare.launcher.R;
import com.techshare.launcher.Sqlite;
import android.support.v4.view.*;
import android.view.View.*;
import java.util.*;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.*;
import android.webkit.*;
import android.graphics.Bitmap;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView.*;
public class FloatingBrowser extends Service {

	private WindowManager windowManager;
	private ViewGroup chatHead;
	private ImageView close,open,go;
	private ArrayList<BookMark> books;
	private ListView list;
	private WebView web;
	private ProgressBar p;
	
	WindowManager.LayoutParams params;

	@Override
	public void onCreate() {
		super.onCreate();

		windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

		books=new ArrayList<BookMark>();
		BookMark book=new BookMark();
		book.icon=getResources().getDrawable(R.drawable.ico);
		book.title="facebook";
		book.link="http://www.facebook.com";
		
		BookMark boo=new BookMark();
		boo.icon=getResources().getDrawable(R.drawable.db);
		boo.title="phpmyadmin";
		boo.link="http://127.0.0.1:9999/phpmyadmin";
		
		
		BookMark bo=new BookMark();
		bo.icon=getResources().getDrawable(R.drawable.local);
		bo.title="Localhost";
		bo.link="http://127.0.0.1:8080";
		
		books.add(book);
		books.add(boo);
		books.add(bo);
		
		LayoutInflater inflater = ( LayoutInflater )getApplicationContext() . getSystemService
		( Context . LAYOUT_INFLATER_SERVICE );

		chatHead = (ViewGroup) inflater.inflate(R.layout.floating_browser, null);		

		params= new WindowManager.LayoutParams(
			WindowManager.LayoutParams.WRAP_CONTENT,
			WindowManager.LayoutParams.WRAP_CONTENT,
			WindowManager.LayoutParams.TYPE_PHONE,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
			PixelFormat.TRANSLUCENT);

		params.gravity = Gravity.TOP | Gravity.LEFT;
		params.x = 0;
		params.y = 100;
		close=(ImageView)chatHead.findViewById(R.id.floatingbrowserImageView1);
		close.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				stopService(new Intent(getApplication(), FloatingBrowser.class));
			}
			
		});
		
		web=(WebView)chatHead.findViewById(R.id.floating_browserWebView);
		p=(ProgressBar)chatHead.findViewById(R.id.floating_browserProgressBar);
		 list=(ListView)chatHead.findViewById(R.id.floating_browserListView);
		BookMarksAdapter adapt=new BookMarksAdapter(getApplicationContext(),books);
		list.setAdapter(adapt);
		list.setOnItemClickListener(new clicker());
		open=(ImageView)chatHead.findViewById(R.id.floatingbrowserImageView2);
		open.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View v){
					if(list.getVisibility()==View.VISIBLE){
						list.setVisibility(View.GONE);
					}else{
						list.setVisibility(View.VISIBLE);
					}

				}

			});
		final EditText 	igo=(EditText)chatHead.findViewById(R.id.floating_browserTextView);
		igo.setOnFocusChangeListener(new OnFocusChangeListener() {
			public void onFocusChange(View v,
									  boolean hasFocus) {
				if (hasFocus){
					InputMethodManager inputMethodManager = (InputMethodManager)getSystemService
					(INPUT_METHOD_SERVICE);
					inputMethodManager.
						toggleSoftInputFromWindow
					(igo.getApplicationWindowToken
					 (), InputMethodManager.SHOW_FORCED,
					 0);
					igo.requestFocus();
					
					//focusedView = v;
				} else {
					//focusedView  = null;
				}
			}
		});
		go=(ImageView)chatHead.findViewById(R.id.floatingbrowsergo);
		go.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View v){
					web.getSettings().setJavaScriptEnabled(true);
					web.loadUrl(igo.getText().toString());
					web.setWebViewClient(new myWebClient());
	;
				}

			});
			
		//this code is for dragging the chat head
		chatHead.setOnTouchListener(new View.OnTouchListener() {
				private int initialX;
				private int initialY;
				private float initialTouchX;
				private float initialTouchY;

				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()) {
						case MotionEvent.ACTION_DOWN:
							initialX = params.x;
							initialY = params.y;
							initialTouchX = event.getRawX();
							initialTouchY = event.getRawY();
							return true;
						case MotionEvent.ACTION_UP:

							if(event.getRawX()<50){
								Sqlite.report(""+event.getRawX(),getApplicationContext());
								stopService(new Intent(getApplication(), FloatingBrowser.class));
							}
							return true;
						case MotionEvent.ACTION_MOVE:


							params.x = initialX
								+ (int) (event.getRawX() - initialTouchX);
							params.y = initialY
								+ (int) (event.getRawY() - initialTouchY);
							windowManager.updateViewLayout(chatHead, params);
							return true;
					}
					return false;
				}
			});
		windowManager.addView(chatHead, params);
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		if (chatHead != null)
			windowManager.removeView(chatHead);
	}

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	private class BookMarksAdapter extends ArrayAdapter<String> {
		private final Context context;
		private final ArrayList<BookMark> values;
		public BookMarksAdapter(Context context, ArrayList<BookMark>
							 values) {
			super (context, R.layout.bookmarks_row, values);
			this .context = context;
			this .values = values;
		}
		@Override
		public View getView( int position, View convertView,
							ViewGroup parent) {
			LayoutInflater inflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View rowView = inflater.inflate(R.layout.bookmarks_row,
											parent, false);
			ImageView pic=(ImageView)rowView.findViewById(R.id.bookmarksrowImageView1);						
			TextView title=(TextView)rowView.findViewById(R.id.bookmarksrowTextView1);
			TextView links=(TextView)rowView.findViewById(R.id.bookmarksrowTextView2);
			title.setText(values.get(position).title);
			links.setText(values.get(position).link);
			pic.setImageDrawable(values.get(position).icon);
			return rowView;
			
			}
		}
		
	private class clicker implements OnItemClickListener
	{

		@Override
		public void onItemClick(AdapterView<?> p1, View p2, int position, long p4)
		{
			// TODO: Implement this method
			web.getSettings().setJavaScriptEnabled(true);
			web.loadUrl(books.get(position).link);
			web.setWebViewClient(new myWebClient());
		}

		}
		
	public class myWebClient extends WebViewClient
	{
		@Override
		public void onPageStarted(WebView view, String url,
								  Bitmap favicon) {
		// TODO Auto-generated method stub
			super.onPageStarted(view, url, favicon);
		}
		@Override
		public boolean shouldOverrideUrlLoading(WebView
												view, String url) {
		// TODO Auto-generated method stub
			//progressBar.setVisibility(View.VISIBLE);
			p.setVisibility(View.VISIBLE);
			view.loadUrl(url);
			return true ;
		}
		@Override
		public void onPageFinished(WebView view, String
								   url) {
		// TODO Auto-generated method stub
			super.onPageFinished(view, url);
			p.setVisibility(View.GONE);
		}

		@Override
		public void onReceivedError(WebView view, int errorCode,
									String description,
									final String failingUrl) {
			web.loadUrl("file:///android_asset/mobile/index.html");

			p.setVisibility(View.GONE);

		}
	}
		
	
		
}
