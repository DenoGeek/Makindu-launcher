package com.techshare.launcher;

import android.content.Context;
import android.preference.*;
import android.app.*;
import android.graphics.Color;
import com.techshare.launcher.utils.HexColorValidator;
import org.apache.http.*;
import android.app.ActivityManager.RunningServiceInfo;
import android.app.Service;
import android.net.ConnectivityManager;

import android.content.Intent;
public class Controler
{
	public static boolean isIntroduced(Context c){
		boolean a=false;
		String check=PreferenceManager.getDefaultSharedPreferences(c)
			.getString("check", null);
			if(check==null){}else{
				a=true;
			}
		return a;
	}
	
	public static boolean isNotLocked(Context c){
		boolean a=true;
		
		String check=PreferenceManager.getDefaultSharedPreferences(c)
			.getString("lock", null);
		if(check==null){}else{
			a=false;
		}
		return a;
	}
	
	public static boolean refreshNeeded(Context c){
		boolean a=false; 
		String ch=PreferenceManager.getDefaultSharedPreferences(c)
			.getString("refresh", null);
		if(ch==null){
			}else{
				a=true;
			}
		return a;
	}
	
	public static boolean isOnline(Context mContext)
    {
        try
        {
            ConnectivityManager cm = (ConnectivityManager)
				mContext.getSystemService
			(Context.CONNECTIVITY_SERVICE);
            return cm.getActiveNetworkInfo().isConnectedOrConnecting();         }
        catch (Exception e)
        {
            return false;
        }
    }
	
	
	public static float[] calculateData(
		float[] data) {
		float total = 0;
		for (int i = 0; i < data.length; i++)
		{
			total += data[i];
		}
		for (int i = 0; i < data.length; i++)
		{
			data[i] = 360 * (data[i] / total);
		}
		return data;
	}
	
	public static String descriptions(String view){
		String d=null;
		switch (view){
		case "selfdestruct":
			d="This is a view that you can use to lock your screen with a bomb like count down timer";
			break;
		case "scareface":
			d="Displays a skull in your homescreen, the skull is animated with moving mouth and flickering eyes";
			break;
		case "calllog":
			d="This is a view that displays the recent calls you made in a command prompt like view";
			break;
		case "prompt":
			d="Shows that different hacking activities of sites are happening in a command shell display";
			break;
		case "cpuview":
			d="The view shows different states of the cpu by you, the system or the other independent processes";
			break;
		case "pielib":
			d="Storage mapper in form of a pie chart, Depends on the values returned by your system";
			break;
		case "photo":
		d="Picks a random photo from the directed folder";
		break;
		case "dock":
		d="A collection of apps to quickly access";
		break;
		default:
			d="This is the most popular hackview in among the Makindu launcher users";
			break;
		}
		return d;
		
	}
	
	public static int pics(String view){
		int d;
		switch (view){
			case "selfdestruct":
				d=R.drawable.destroy;
				break;
			case "scareface":
				d=R.drawable.skull;
				break;
			case "calllog":
				d=R.drawable.recents;
				break;
			case "prompt":
				d=R.drawable.prompt;
				break;
			case "cpuview":
				d=R.drawable.cpu;
				break;
			case "pielib":
				d=R.drawable.storage;
				break;
			case "photo":
				d=R.drawable.photo;

				break;
			case "dock":
				d=R.drawable.dock;
				break;
			default:
				d=R.drawable.prompt;
				break;
		}
		return d;

	}
	
	
	public static String pimpColor(Context c){
		
		String ch=PreferenceManager.getDefaultSharedPreferences(c)
			.getString("color", null);
		return ch;
	}
	
	
	public static String loadDir(Context c){
		
		String ch=PreferenceManager.getDefaultSharedPreferences(c)
			.getString("dir", null);
		
			return ch;
	}
	
	
	public static void saveDir(String s,Context c){
		
		PreferenceManager.getDefaultSharedPreferences(c)
			.edit().putString("dir",s).commit();
		
	}
	
	
	public static void saveCol(String s,Context c){

		PreferenceManager.getDefaultSharedPreferences(c)
			.edit().putString("color",s).commit();
		
	}
	
	
	public static boolean isColor(String col){
		boolean g=false;
		
		HexColorValidator h=new HexColorValidator();
		if(h.validate(col)){
			g=true;
		}
		return g;
	}
	//These are the booleans controlling the shit ya tutorial
	public static boolean settingsShown(Context c){
		boolean a=false; 
		String ch=PreferenceManager.getDefaultSharedPreferences(c)
			.getString("settings", null);
		if(ch!=null){
		}else{
			a=true;
		}
		return a;
	}
	
	public static boolean padlockShown(Context c){
		boolean a=false; 
		String ch=PreferenceManager.getDefaultSharedPreferences(c)
			.getString("padlock", null);
		if(ch!=null){
		}else{
			a=true;
		}
		return a;
	}
	
	public static boolean hackHelpShown(Context c){
		boolean a=false; 
		String ch=PreferenceManager.getDefaultSharedPreferences(c)
			.getString("hackhelp", null);
		if(ch!=null){
		}else{
			a=true;
		}
		return a;
	}
	
	public static boolean homeHelpShown(Context c){
		boolean a=false; 
		String ch=PreferenceManager.getDefaultSharedPreferences(c)
			.getString("homehelp", null);
		if(ch!=null){
		}else{
			a=true;
		}
		return a;
	}
	
	public static boolean menuHelpShown(Context c){
		boolean a=false; 
		String ch=PreferenceManager.getDefaultSharedPreferences(c)
			.getString("menuHelp", null);
		if(ch!=null){
		}else{
			a=true;
		}
		return a;
	}
	
	public static boolean hacksHelpShown(Context c){
		boolean a=false; 
		String ch=PreferenceManager.getDefaultSharedPreferences(c)
			.getString("hacksHelp", null);
		if(ch!=null){
		}else{
			a=true;
		}
		return a;
	}
	
	public static boolean pmenuHelpShown(Context c){
		boolean a=false; 
		String ch=PreferenceManager.getDefaultSharedPreferences(c)
			.getString("pmenuHelp", null);
		if(ch!=null){
		}else{
			a=true;
		}
		return a;
	}
	
	
	public static boolean isMyServiceRunning
	(Class<?> serviceClass,Context c) {
		ActivityManager manager = (ActivityManager)c. getSystemService
		(Context.ACTIVITY_SERVICE);
		for (RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
			if (serviceClass.getName().equals
				(service.service.getClassName())) {
				return true;
			}
		}
		return false;
	}
	
	
	
	public static void ofsetBoolean(Context c,int id){
		String[] booleans={
			"settings",
			"padlock",
			"homehelp",
			"hackhelp",
			"menuHelp",
			"hacksHelp",
			"pmenuHelp"
		
		};
		
		PreferenceManager.getDefaultSharedPreferences(c)
			.edit().putString(booleans[id],"Done").commit();
		
		
	}
	
	
}
