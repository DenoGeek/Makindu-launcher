package com.techshare.launcher;


import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.LinearLayout;
import android.widget.GridView;
import android.widget.TextView;
import android.graphics.*;
import android.graphics.Paint.*;
import android.graphics.drawable.shapes.*;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.Drawable;
import android.widget.ProgressBar;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.SystemClock;
import java.util.Random;
import android.view.WindowManager;
import 
android.text.method.ScrollingMovementMethod;
import android.util.*;
import android.provider.CallLog;
import android.database.Cursor;
import android.content.Context;
import java.util.Date;
public class RecentsPrompt extends RelativeLayout
{

	private String title,footer;
	private int topCol;
	private String[] calls;



	//temporary variables
	String[] web = {
		"Google" ,
		"Github" ,
		"Instagram" ,
		"Facebook" ,
		"Google" ,
		"Github" ,
		"Instagram" ,
		"Facebook" ,


	} ;
	int[] imageId = {
		R.drawable.ic_launcher,
		R.drawable.ic_launcher,
		R.drawable.ic_launcher,
		R.drawable.ic_launcher,
		R.drawable.ic_launcher,
		R.drawable.ic_launcher,
		R.drawable.ic_launcher,
		R.drawable.ic_launcher

	};


    private ProgressBar customProgress;
    private TextView progressDisplay;
	private TextView pane;



	public RecentsPrompt(Context context, AttributeSet attrs){
		super(context, attrs);
		//paint object for drawing in onDraw


		//at this point try fetching custom attributes
		TypedArray a = context.getTheme().obtainStyledAttributes
		(attrs,
		 R.styleable.CustomGrid, 0, 0);


		try {
			//get the text and colors specified using thenames in attrs.xml
			title = a.getString(R.styleable.CustomGrid_gridTitle);
			footer = a.getString(R.styleable.CustomGrid_gridFooter);//0 is default
			topCol = a.getInteger(R.styleable.CustomGrid_gridTitleBg, 0);
		} finally {
			a.recycle();
		}
		//the kimoda shadows ...here ni wazimu wa mawazimu
		RoundRectShape rss = new RoundRectShape(new float[]{ 12f, 12f, 12f,12f, 12f, 12f, 12f, 12f }, null, null);
		ShapeDrawable sds = new ShapeDrawable(rss);
		sds.setShaderFactory(new ShapeDrawable.ShaderFactory
			() {
				@Override
				public Shader resize(int width, int height) {
					LinearGradient lg = new LinearGradient(0, 0, 0, height,
														   new int[] { Color.parseColor("#e5e5e5"),
															   Color.parseColor("#e5e5e5"),
															   Color.parseColor("#e5e5e5"),
															   Color.parseColor("#ffffff") }, new float[] {
															   0,
															   0.50f, 0.50f, 1 }, Shader.TileMode.REPEAT);
					return lg;
				}
			});
		LayerDrawable ld = new LayerDrawable(new Drawable[] { sds, sds });ld.setLayerInset(0, 5, 5, 0, 10); 
		// inset the shadow so itdoesn't start right at the left/top
		ld.setLayerInset(1, 0, 0, 5, 5); 
		// inset the top drawableso we can leave a bit of space for the shadow to use



		//setOrientation(LinearLayout.HORIZONTAL);
		//setGravity(Gravity.CENTER_VERTICAL);

		LayoutInflater inflater = (LayoutInflater) context
			.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		inflater.inflate(R.layout.prompt, this, true);

		/*TextView title = (TextView) getChildAt(0);
		 title.setText("titleText");
		 title.setBackgroundColor(topCol);

		 TextView footer = (TextView) getChildAt(4);
		 footer.setText("titleText");


		 GridView grid = (GridView) getChildAt(2);


		 CustomGridAdapter adapter = new CustomGridAdapter(context,
		 web, imageId);
		 grid.setAdapter(adapter);
		 */

		customProgress = (ProgressBar)getChildAt(3);
        progressDisplay = (TextView)getChildAt(4);
		pane=(TextView)getChildAt(2);
		pane.setMovementMethod(new ScrollingMovementMethod());
		new ShowCustomProgressBarAsyncTask().execute();
		getCallDetails(context);
		//The layout vimoda parts
		WindowManager windowManager = (WindowManager)
			context
			.getSystemService(Context.WINDOW_SERVICE);

		int width=windowManager.getDefaultDisplay()
			.getWidth()/10*3;
		int height=windowManager.getDefaultDisplay()
			.getHeight()/10*1;
		LinearLayout.LayoutParams layoutParams = new
			LinearLayout.LayoutParams(width,height);
		layoutParams.setMargins(15, 6, 15, 10);
		layoutParams.height=220;
		
		if(Controler.pimpColor(context)!=null){
			if(Controler.isColor(Controler.pimpColor(context))){
				pane.setBackgroundColor(Color.parseColor(Controler.pimpColor(context)));
			}
		}


		//this.setPadding(5,5,5,5);
		this.setBackground(getResources().getDrawable(R.drawable.glas));
		this.setLayoutParams(layoutParams);
		
	}



	private class ShowCustomProgressBarAsyncTask extends AsyncTask<Void, Integer, Void> {

        int myProgress;

        @Override
        protected void onPreExecute() {
            myProgress = 0;
			pane.setText("");
        }

        @Override
        protected Void doInBackground(Void... params) {
            while(myProgress<100){
                myProgress++;
                publishProgress(myProgress);
                SystemClock.sleep(500);
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            customProgress.setProgress(values[0]);
            customProgress.setSecondaryProgress(values[0] + 1);
            progressDisplay.setText(String.valueOf(myProgress)+"%");
			Random r = new Random();
			int max=calls.length;
			int i1 = r.nextInt(max - 0) + 0;
			addMessage("Hacking into"+calls[i1]);


		}

        @Override
        protected void onPostExecute(Void result) {
			new ShowCustomProgressBarAsyncTask().execute();
        }

	}
	// function to append a string to a TextView as a new line
// and scroll to the bottom if needed
	private void addMessage(String msg) {
		// append the new string
		pane.append(msg + "\n");
		// find the amount we need to scroll.  This works by
		// asking the TextView's internal layout for the position
		// of the final line and then subtracting the TextView'sheight
		/*final int scrollAmount = pane.getLayout()
		 .getLineTop(pane.getLineCount()) -
		 pane.getHeight();
		 // if there is no need to scroll, scrollAmount will be <=0
		 if (scrollAmount > 0)
		 pane.scrollTo(0, scrollAmount);
		 else
		 pane.scrollTo(0, 0);*/
	}


	
	private void getCallDetails(Context c) {
		StringBuilder sb=new StringBuilder();
		Cursor managedCursor = c. getContentResolver().query
		(android.provider.CallLog.Calls.CONTENT_URI,null, null,
		 null,null);int number = managedCursor.getColumnIndex
( CallLog.Calls.NUMBER );
int type = managedCursor.getColumnIndex
( CallLog.Calls.TYPE );
int date = managedCursor.getColumnIndex
( CallLog.Calls.DATE);
int duration = managedCursor.getColumnIndex
( CallLog.Calls.DURATION);
sb.append( "Call Details :");
while ( managedCursor.moveToNext() ) {
		String phNumber = managedCursor.getString( number );
		String callType = managedCursor.getString( type );
		String callDate = managedCursor.getString( date );
		Date callDayTime = new Date(Long.valueOf(callDate));
		String callDuration = managedCursor.getString( duration );
		String dir = null;
		int dircode = Integer.parseInt( callType );
switch( dircode ) {
	case CallLog.Calls.OUTGOING_TYPE:
		dir = "OUTGOING";
break;
	case CallLog.Calls.INCOMING_TYPE:
		dir = "INCOMING";
break;
	case CallLog.Calls.MISSED_TYPE:
		dir = "MISSED";
break;
}
sb.append( "Retrieving log of "+phNumber +"Activity under:--- "+dir+"On :--- "+callDayTime+" Over--- "+callDuration );
sb.append(";");
}
managedCursor.close();
calls=sb.toString().split(";");

}

}
