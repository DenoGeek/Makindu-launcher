package com.techshare.launcher;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import com.techshare.launcher.fragments.NewsFragment;

public class HomePagerAdapter extends FragmentPagerAdapter {
	private Context _context;

	public HomePagerAdapter(Context context, FragmentManager fm) {
		super(fm);	
		_context=context;

	}
	@Override
	public Fragment getItem(int position) {
		Fragment f = new Fragment();
		switch(position){
			case 4:
				f=HomeAllAppsFragment.newInstance(_context);	
				break;
			
			case 3:
				f=HomeHacksFragment.newInstance(_context);	
				break;
			case 0:
				f=NewsFragment.newInstance(_context);	
				break;
			case 1:
				f=HomeWidgetsFragment.newInstance(_context);	
				break;
			case 2:
				f=HomeWidgetFragmentsTwo.newInstance(_context);	
				break;
		}
		return f;
	}
	@Override
	public int getCount() {
		return 5;
	}
	
	@Override
	public int getItemPosition(Object object){
		return POSITION_NONE;
	}
	
	
	public void refresh(){
		this.notifyDataSetChanged();
	}

}
