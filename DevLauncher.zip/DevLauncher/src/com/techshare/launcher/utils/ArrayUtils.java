package com.techshare.launcher.utils;

import java.util.*;

public class ArrayUtils {
		public static <T> void reArrange
		(List<T> list,int from, int to){
			if(from != to){
				if(from > to)
					reArrange(list,from -1, to);
				else
					reArrange(list,from +1, to);
				Collections.swap(list, from, to);
			}
		}
    }
