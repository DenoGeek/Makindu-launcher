package com.techshare.launcher;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.*;
import android.util.AttributeSet;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.*;
import android.content.Context;
import android.content.Intent;
import android.webkit.*;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.database.*;
import android.database.sqlite.*;
import android.widget.LinearLayout.*;
import android.os.Handler;
import android.graphics.PointF;
import com.techshare.launcher.views.*;

import com.easyandroidanimations.library.RotationAnimation;
import com.easyandroidanimations.library.Animation;
import com.easyandroidanimations.library.AnimationListener;

public class HomeHacksFragment extends Fragment {

	ViewGroup root;
	FrameLayout main;
	public static Fragment newInstance(Context context) {
		HomeHacksFragment f = new HomeHacksFragment();	
		
		return f;
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
		 root = (ViewGroup) inflater.inflate(R.layout.hacks_fragments, null);		
		 main=(FrameLayout)root.findViewById(R.id.hacks_frame);
		
		loadViews(getActivity().getApplicationContext());
		
		
		return root;
	}
	
	
	private void QuitApplication(){
		int pid = android.os.Process.myPid();
		android.os.Process.killProcess(pid);
		Toast.makeText(getActivity().getApplicationContext(),"Restarting",Toast.LENGTH_SHORT).show();
		Intent intent = new Intent(Intent.ACTION_MAIN);
		intent.setFlags(intent.FLAG_ACTIVITY_NEW_TASK);
		intent.addCategory(Intent.CATEGORY_HOME);
		startActivity(intent);
	}
	
	public void loadViews(Context cc){
		main.removeAllViews();
		String dbName = "makindu";
		String tableViews="views";
		SQLiteDatabase myDb = null;
		String state="1";
		try{
			myDb =  cc.openOrCreateDatabase(dbName,Context. MODE_PRIVATE, null);
			
			Cursor c = myDb.rawQuery("SELECT * FROM "+tableViews+" WHERE state ="+state+" ORDER BY id desc", null);
        	//If Cursor is valid
        	if (c != null ) {
        		//Move cursor to first row
        		if  (c.moveToFirst()) {
        			do {
        				//Get version from Cursor
        				String tag = c.getString(c.getColumnIndex("tag"));
						String xcor = c.getString(c.getColumnIndex("xcor"));
						String ycor= c.getString(c.getColumnIndex("ycor"));
						createView(tag,xcor,ycor);
					}while (c.moveToNext()); //Move to next row
        		} 
        	}

		}catch (SQLiteException se ) {
			Sqlite.report("Couldnt Load views data",cc);
		} finally {
			
		}
		
		
	}
	
	
	public void createView(String tag,String xcor,String ycor){
		
		
		AttributeSet attrs=null;
		
		//The layout vimoda parts
		WindowManager windowManager = (WindowManager)
			getActivity().getApplicationContext()
			.getSystemService(Context.WINDOW_SERVICE);

		int width=windowManager.getDefaultDisplay()
			.getWidth()/10*6;
		int height=windowManager.getDefaultDisplay()
			.getHeight()/10*5;	
		switch(tag.trim()){
			
				case "selfdestruct":
				FrameLayout.LayoutParams layoutParams = new
					FrameLayout.LayoutParams(320,100);
				layoutParams.gravity = Gravity.TOP;
				layoutParams.setMargins(Sqlite.inTise(xcor),Sqlite.inTise(ycor),0,0);
				
				SelfDestroy h=new SelfDestroy(getActivity().getApplicationContext(),attrs);
				h.setLayoutParams(layoutParams);
				h.setTag(tag);
				h.setOnTouchListener(new Mover());
				h.setOnLongClickListener(new LongListener());
				main.addView(h);
					
				break;
				
				case "scareface":
					
				FrameLayout.LayoutParams scareParams = new
					FrameLayout.LayoutParams(width,width);
				scareParams.gravity = Gravity.TOP;
				scareParams.setMargins(Sqlite.inTise(xcor),Sqlite.inTise(ycor),0,0);

				ScareFaceView sp=new ScareFaceView(getActivity().getApplicationContext());
				sp.setLayoutParams(scareParams);
				sp.setTag(tag);
				sp.setOnTouchListener(new Mover());
				main.addView(sp);
					break;
					
			case "photo":

				FrameLayout.LayoutParams photoParams = new
					FrameLayout.LayoutParams(width,width);
				photoParams.gravity = Gravity.TOP;
				photoParams.setMargins(Sqlite.inTise(xcor),Sqlite.inTise(ycor),0,0);

				RandomPhotoFrame spp=new RandomPhotoFrame(getActivity().getApplicationContext());
				spp.setLayoutParams(photoParams);
				spp.setTag(tag);
				spp.setOnTouchListener(new Mover());
				main.addView(spp);
				break;
					
				case "calllog":
				FrameLayout.LayoutParams layoutParamsi = new
					FrameLayout.LayoutParams(width,height);
				layoutParamsi.gravity = Gravity.TOP;
				layoutParamsi.setMargins(Sqlite.inTise(xcor),Sqlite.inTise(ycor),0,0);
				
				RecentsPrompt y=new RecentsPrompt(getActivity().getApplicationContext(),attrs);
				y.setLayoutParams(layoutParamsi);
				y.setTag(tag);
				y.setOnTouchListener(new Mover());
				y.setOnLongClickListener(new LongListener());
				main.addView(y);
					break;
					
					
				case "cpuview":
				FrameLayout.LayoutParams cpuParams = new
					FrameLayout.LayoutParams(width,width);
				cpuParams.gravity = Gravity.TOP;
				cpuParams.setMargins(Sqlite.inTise(xcor),Sqlite.inTise(ycor),0,0);

				CpuView cp=new CpuView(getActivity().getApplicationContext());
				cp.setLayoutParams(cpuParams);
				cp.setTag(tag);
				cp.setOnTouchListener(new Mover());
				main.addView(cp);
					
					break;
					
				case "pielib":
					
				FrameLayout.LayoutParams pieParams = new
					FrameLayout.LayoutParams(width,width);
				pieParams.gravity = Gravity.TOP;
				pieParams.setMargins(Sqlite.inTise(xcor),Sqlite.inTise(ycor),0,0);
				
				PieLib a=new PieLib(getActivity().getApplicationContext());
				a.setLayoutParams(pieParams);
				a.setTag(tag);
				a.setOnTouchListener(new Mover());
				main.addView(a);
					
						break;
						
			case "dock":

				FrameLayout.LayoutParams dockParams = new
					FrameLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT,100);
				dockParams.gravity = Gravity.TOP;
				dockParams.setMargins(Sqlite.inTise(xcor),Sqlite.inTise(ycor),0,0);

				DockBar aa=new DockBar(getActivity().getApplicationContext());
				aa.setLayoutParams(dockParams);
				aa.setTag(tag);
				aa.setOnTouchListener(new Mover());
				main.addView(aa);

				break;
					
				default:
				FrameLayout.LayoutParams layoutParam = new
					FrameLayout.LayoutParams(width,height);
				layoutParam.gravity = Gravity.TOP;
				layoutParam.setMargins(Sqlite.inTise(xcor),Sqlite.inTise(ycor),0,0);
				
				PromtView p=new PromtView(getActivity().getApplicationContext(),attrs);
				p.setLayoutParams(layoutParam);
				p.setTag(tag);
				p.setOnTouchListener(new Mover());
				p.setOnLongClickListener(new LongListener());
				main.addView(p);
					
		}		
	}
	
	private class LongListener implements OnLongClickListener{
		
		@Override
		public boolean onLongClick(View v) {
			v.setOnTouchListener(new Mover());
			return true;
		}
	}
	
	
	private class Mover implements OnTouchListener{
		PointF DownPT = new PointF(); // RecordMouse Position When Pressed Down
		PointF StartPT = new PointF(); // Record StartPosition of 'img'
		@Override
		public boolean onTouch(final View v, MotionEvent
							   event)
		{
			int eid = event.getAction();
			switch (eid)
			{
				case MotionEvent.ACTION_MOVE :
					PointF mv = new PointF( event.getX() -
										   DownPT.x, event.getY() - DownPT.y);
					v.setX((int)(StartPT.x+mv.x));
					v.setY((int)(StartPT.y+mv.y));
					StartPT = new PointF( v.getX(),
										 v.getY() );
					break;
				case MotionEvent.ACTION_DOWN :
					int children=main.getChildCount();
					final int thisviewindex=main.indexOfChild(v);
					if(thisviewindex+1!=children){
						//Sqlite.report(""+v.getTag().toString()+children+thisviewindex,getActivity());
						
							new RotationAnimation(main.getChildAt(thisviewindex))
								.setPivot(RotationAnimation.PIVOT_TOP_LEFT)
								.setListener(new AnimationListener(){
									@Override
									public void onAnimationEnd(Animation a){
										String[] aji=Sqlite.ViewCors(getActivity().getApplicationContext(),v.getTag().toString());
										main.removeViewAt(thisviewindex);
										createView(aji[0],aji[1],aji[2]);
										
									}
								})
								.setDuration(1000)
								.animate();
						
						
					}
					
					DownPT.x = event.getX();
					DownPT.y = event.getY();
					StartPT = new PointF( v.getX(),
										 v.getY() );
					break;
				case MotionEvent.ACTION_UP :
					// Nothing have to do
					int childre=main.getChildCount();
					final int thisviewinde=main.indexOfChild(v);
					if(thisviewinde+1==childre){
						
					update(getActivity().getApplicationContext(),v.getTag().toString(),(int)v.getX(),(int)v.getY());
					}
					break;
				default :
					break;
			}
			return true;
		}
	
		
	};
	
	
	
	public void update(final Context c,String tag,int xcor,int ycor){
		String dbName = "makindu";
		String tableViews="views";
		SQLiteDatabase myDb = null;
		try{
			myDb =  c.openOrCreateDatabase(dbName, Context.MODE_PRIVATE, null);

			myDb.execSQL( "UPDATE " + tableViews + " SET xcor = '"+xcor+"' WHERE tag='"+tag+"'" ); 		
			myDb.execSQL( "UPDATE " + tableViews + " SET ycor = '"+ycor+"' WHERE tag='"+tag+"'" ); 		
			
		}catch (SQLiteException se ) {
        	Toast.makeText(c, "Couldn't update into databasedatabase", Toast.LENGTH_LONG).show();
        } finally {
        	if (myDb != null) {
				//Sqlite.report("updated",c);
				}
		}
		
	}
	
	/*new Handler().postDelayed(new Runnable(){
						@Override
						public void run() {
        			//loadViews(c);
				}},100);
        	*/
}
