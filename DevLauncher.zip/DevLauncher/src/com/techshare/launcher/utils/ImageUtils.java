package com.techshare.launcher.utils;


import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Bitmap.Config;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.BitmapDrawable;
public class ImageUtils
{

    public static Bitmap getCircleBitmap(Bitmap bitmap)
    {
        return getCircleBitmap(bitmap, bitmap.getWidth(), bitmap.getHeight());
    }

    public static Bitmap getCircleBitmap(Bitmap bitmap, int width, int height)
    {
        Bitmap croppedBitmap = scaleCenterCrop(bitmap, width, height);
        Bitmap output = Bitmap.createBitmap(width, height, Config.ARGB_8888);
        Canvas canvas = new Canvas(output);

        final int color = 0xff424242;
        final Paint paint = new Paint();

        final Rect rect = new Rect(0, 0, width, height);

        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);

        int radius =  (width > height) ? height : width;
        radius /= 2;

        canvas.drawCircle(width / 2, height / 2, radius, paint);
        paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
        canvas.drawBitmap(croppedBitmap, rect, rect, paint);

        return output;
    }

    public static Bitmap scaleCenterCrop(Bitmap source, int newHeight, int newWidth)
    {
        int sourceWidth = source.getWidth();
        int sourceHeight = source.getHeight();

        float xScale = (float) newWidth / sourceWidth;
        float yScale = (float) newHeight / sourceHeight;
        float scale = Math.max(xScale, yScale);

        float scaledWidth = scale * sourceWidth;
        float scaledHeight = scale * sourceHeight;

        float left = (newWidth - scaledWidth) / 2;
        float top = (newHeight - scaledHeight) / 2;

        RectF targetRect = new RectF(left, top, left + scaledWidth, top + scaledHeight);

        Bitmap dest = Bitmap.createBitmap(newWidth, newHeight, source.getConfig());
        Canvas canvas = new Canvas(dest);
        canvas.drawBitmap(source, null, targetRect, null);

        return dest;
    }
	
	public static Bitmap drawableToBitmap (Drawable drawable) {
		Bitmap bitmap = null;
		if (drawable instanceof BitmapDrawable)
		{
			BitmapDrawable bitmapDrawable = (BitmapDrawable) drawable;
			if(bitmapDrawable.getBitmap() != null)
			{
				return bitmapDrawable.getBitmap();
			}
		}
		if(drawable.getIntrinsicWidth() <= 0 || drawable.getIntrinsicHeight() <= 0) {
			bitmap = Bitmap.createBitmap(1, 1,
										 Bitmap.Config.ARGB_8888); // Single color bitmap will be created of 1x1 pixel
		} else {
			bitmap = Bitmap.createBitmap
			(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(),
			 Bitmap.Config.ARGB_8888);
		}
		Canvas canvas = new Canvas(bitmap);
		drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
		drawable.draw(canvas);
		return bitmap;
	}
	
	
	
	public static Bitmap scaleCropToFit
	(Bitmap original, int targetWidth, int targetHeight){
		//Need to scale the image, keeping the aspect ration first
		int width = original.getWidth();
		int height = original.getHeight();
		float widthScale = (float) targetWidth / (float) width;
		float heightScale = (float) targetHeight / (float) height;
		float scaledWidth;
		float scaledHeight;
		int startY = 0;
		int startX = 0;
		if (widthScale > heightScale) {
			scaledWidth = targetWidth;
			scaledHeight = height * widthScale;
			//crop height by...
			startY = (int) ((scaledHeight - targetHeight) / 2);
		} else {
			scaledHeight = targetHeight;
			scaledWidth = width * heightScale;
			//crop width by..
			startX = (int) ((scaledWidth - targetWidth) / 2);
		}
		Bitmap scaledBitmap =
			Bitmap.createScaledBitmap(original, (int) scaledWidth, (int) scaledHeight, true);
		Bitmap resizedBitmap =
			Bitmap.createBitmap(scaledBitmap, startX, startY, targetWidth, targetHeight);
		return resizedBitmap;
	}
	
	
	public static Bitmap cropToSquare(Bitmap bitmap){
		int width  = bitmap.getWidth();
		int height = bitmap.getHeight();
		int newWidth = (height > width) ? width : height;
		int newHeight = (height > width)? height - ( height - width) : height;
		int cropW = (width - height) / 2;
		cropW = (cropW < 0)? 0: cropW;
		int cropH = (height - width) / 2;
		cropH = (cropH < 0)? 0: cropH;
		Bitmap cropImg = Bitmap.createBitmap
		(bitmap, cropW, cropH, newWidth, newHeight);
		return cropImg;
	}
	
}
