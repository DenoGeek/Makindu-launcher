package com.techshare.launcher;

import android.support.v4.app.FragmentActivity;
import android.os.*;
import android.view.*;
import android.database.*;
import android.database.sqlite.*;
import android.content.Context;
import java.util.*;
import android.widget.ArrayAdapter;
import android.widget.*;
import android.view.View.*;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.content.Intent;

import com.techshare.launcher.utils.ArrayUtils;
import com.techshare.launcher.fragments.*;
import com.techshare.launcher.views.*;

public class ConfigureApp extends FragmentActivity
{
	
	@Override
	protected void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		setContentView(R.layout.configure_app);
		
		
		
		ConfigureHacks webfrag = new ConfigureHacks();
        Bundle bundle = new Bundle();
		bundle.putString("web", "web");
		webfrag.setArguments(bundle);
		FragmentTransaction ft = getSupportFragmentManager()
			.beginTransaction();
		ft.setCustomAnimations(R.anim.slideleft,
							   R.anim.slideright);
		ft.replace(R.id.configure_appFrameLayout, webfrag,"fragment");
		// Start the animated transition.
		ft.commit();
		
		
		}
		
		
	@Override
	protected void onPause() {
		super .onPause();
		//Sqlite.report("paused",getApplicationContext());
		//Log . d (msg , "The onPause() event" );
		if(Controler.isMyServiceRunning(InstructView.class,getApplicationContext())){
			Intent si=new Intent(getApplication(), InstructView.class);
			si.putExtra("id","0");
			stopService(si);
		}
		finish();
	}
		
}
