package com.techshare.launcher.views;

import android.view.*;
import android.content.Context;
import android.webkit.*;
import android.widget.*;
import com.techshare.launcher.R;
public class ScareFaceView extends LinearLayout
{
	WebView web;
	
	public ScareFaceView(Context c){
		super(c);
		
		LinearLayout.LayoutParams webpars=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT,LinearLayout.LayoutParams.FILL_PARENT);
		
		web=new WebView(c);
		web.setLayoutParams(webpars);
		web.getSettings().setJavaScriptEnabled(true);
		web.loadUrl("file:///android_asset/index.html");
		web.setBackgroundColor(0x00000000);
		this.addView(web);
		this.setBackgroundResource(R.drawable.glas);
	}
}
