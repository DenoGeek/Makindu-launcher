package com.techshare.launcher;

import android.widget.*;
import android.content.Context;
import java.util.*;
import android.graphics.*;

public class ActionGridView extends GridView
{ 
	
	public ActionGridView(Context context){
		super(context);
		this.setNumColumns(3);
		this.setColumnWidth(110);
		//now set the grid view adapters
		String options[]={"Open hack","Open","Uninstall","Details","Favourite","Unfavourite","Add to home","Add to Dock"};
		int icons[]={R.drawable.hac,R.drawable.ope,R.drawable.uni,R.drawable.det,R.drawable.addfav,R.drawable.fav,R.drawable.home,R.drawable.dock};
		List<HashMap<String,String>> aList = new
			ArrayList<HashMap<String,String>>();
		for (int i= 0;i< 8 ;i++){
			HashMap<String, String> hm = new
				HashMap<String,String>();
			hm.put( "txt" , options[i]);
			hm.put( "flag" , Integer.toString(icons[i]) );
			aList.add(hm);
		}
		String[] from = { "flag" ,"txt" };
		int [] to = { R.id.flag,R.id.txt};
		SimpleAdapter adapter = new SimpleAdapter(context, aList, R.layout.gridview_layout, from, to);
		
		
		this.setAdapter(adapter);
		this.setBackgroundColor(Color.parseColor("#ffffff"));
	}
}
