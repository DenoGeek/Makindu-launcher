package com.techshare.launcher;

import android.widget.*;
import android.content.*;
import android.view.*;
import android.graphics.drawable.Drawable;

public class WidgetApp extends LinearLayout
{
	
	public WidgetApp(Context c,String name,String pname){
		super(c);
		
		final float inPixels= c.getResources
		().getDimension(R.dimen.app_width);
		
		
		ImageView g=new ImageView(c);
		LinearLayout.LayoutParams gpar = new
			LinearLayout.LayoutParams((int)inPixels,(int)inPixels);
		g.setLayoutParams(gpar);
		//g.setImageResource(R.drawable.icon);
		try {
			Drawable d = c.getPackageManager().getApplicationIcon
			(pname);
			//g.setBackgroundDrawable(d);
			g.setImageDrawable(d);
		} catch(Exception  e) {
			//Sqlite.delete(c,t);

			e.printStackTrace();
		}

		
		
		
		TextView t=new TextView(c);
		LinearLayout.LayoutParams tpar = new
			LinearLayout.LayoutParams((int)inPixels,30);
		t.setLayoutParams(tpar);
		t.setText(name);
		t.setSingleLine(true);
		t.setTextSize(12);
		
		this.setOrientation(LinearLayout.VERTICAL);
		this.addView(g);
		this.addView(t);
		
	}
	
}
