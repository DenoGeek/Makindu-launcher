package com.techshare.launcher;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsManager;
import android.widget.Toast;
import android.preference.*;

public class AppListener extends
BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent
						  intent) {
        // Receive install the radio
        if (intent.getAction().equals
					("android.intent.action.PACKAGE_ADDED")) {
            String packageName = intent.getDataString();
            System.out.println("installed:" +
						 packageName
							   + "package name of the program");
            Toast.makeText
			(context.getApplicationContext(), "A new Application has been installed",
			 Toast.LENGTH_LONG).show();
					PreferenceManager.getDefaultSharedPreferences(context)
						.edit().putString("refresh","Done").commit();
				
        }
        // Receive uninstall broadcast
        if (intent.getAction().equals
			("android.intent.action.PACKAGE_REMOVED")) {
            String packageName = intent.getDataString();
            System.out.println("uninstall:" +
							   packageName
							   + "package name of the program");
							   
			if(Sqlite.isFav(packageName,context)){
				Sqlite.delete(context,packageName);
			}
			if(Sqlite.isHome(packageName,context)){
				Sqlite.deleteApp(context,packageName);
			}
            Toast.makeText
			(context.getApplicationContext(), "Application uninstalled",
			 Toast.LENGTH_LONG).show();
			PreferenceManager.getDefaultSharedPreferences(context)
				.edit().putString("refresh","Done").commit();
			
        }
    }
}
