package com.techshare.launcher;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.view.*;
import android.content.Context;
import android.view.View.*;
import android.widget.*;
import com.techshare.launcher.views.*;


public class ChatHeadService extends Service {

	private WindowManager windowManager;
	private ViewGroup chatHead;
	
	private ImageView main;
	private LinearLayout container;
	WindowManager.LayoutParams params;

	@Override
	public void onCreate() {
		super.onCreate();

		windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

		
		
		
		LayoutInflater inflater = ( LayoutInflater )getApplicationContext() . getSystemService
		( Context . LAYOUT_INFLATER_SERVICE );
		
		chatHead = (ViewGroup) inflater.inflate(R.layout.chat_head, null);		
		
		params= new WindowManager.LayoutParams(
				WindowManager.LayoutParams.WRAP_CONTENT,
				WindowManager.LayoutParams.WRAP_CONTENT,
				WindowManager.LayoutParams.TYPE_PHONE,
				WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
				PixelFormat.TRANSLUCENT);

		params.gravity = Gravity.TOP | Gravity.LEFT;
		params.x = 0;
		params.y = 100;
		
		//this code is for dragging the chat head
		chatHead.setOnTouchListener(new Movie());
		main=(ImageView)chatHead.findViewById(R.id.circular_image_view);
		container=(LinearLayout)chatHead.findViewById(R.id.chat_headLinearLayout);
		main.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View v){
				if(container.getVisibility()==View.VISIBLE){
					container.setVisibility(View.GONE);
				}else{
					container.setVisibility(View.VISIBLE);
				}
			}
		});
		
		actionBtn a=new actionBtn(getApplicationContext(),"Browser",R.drawable.fav);
		a.setOnClickListener(new gongwa());
		a.setTag("browser");
		container.addView(a);
		windowManager.addView(chatHead, params);
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		if (chatHead != null)
			windowManager.removeView(chatHead);
	}

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}
	
	private class Movie implements OnTouchListener{
		private int initialX;
		private int initialY;
		private float initialTouchX;
		private float initialTouchY;

		@Override
		public boolean onTouch(View v, MotionEvent event) {
			switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:
					initialX = params.x;
					initialY = params.y;
					initialTouchX = event.getRawX();
					initialTouchY = event.getRawY();
					return true;
				case MotionEvent.ACTION_UP:

					if(event.getRawX()<50){
						Sqlite.report(""+event.getRawX(),getApplicationContext());
					}
					return true;
				case MotionEvent.ACTION_MOVE:


					params.x = initialX
						+ (int) (event.getRawX() - initialTouchX);
					params.y = initialY
						+ (int) (event.getRawY() - initialTouchY);
					windowManager.updateViewLayout(chatHead, params);
					return true;
			}
			return false;
		}
		
	}
	
	
	private class actionBtn extends LinearLayout{
		
		public actionBtn(Context context,String text,int d){
			super(context);
			LinearLayout.LayoutParams mpar = new
				LinearLayout.LayoutParams(40,45);
				mpar.setMargins(5,5,0,0);
			
			ImageView g=new ImageView(context);
			LinearLayout.LayoutParams gpar = new
				LinearLayout.LayoutParams(30,30);
			g.setLayoutParams(gpar);
			g.setImageResource(d);
			
			TextView t=new TextView(context);
			LinearLayout.LayoutParams tpar = new
				LinearLayout.LayoutParams(37,10);
			t.setLayoutParams(tpar);
			t.setText(text);
			t.setTextSize(8);

			this.setOrientation(LinearLayout.VERTICAL);
			this.addView(g);
			this.addView(t);
			this.setLayoutParams(mpar);
		}
		
		
		
	}
	
	private class gongwa implements OnClickListener
	{

		@Override
		public void onClick(View v)
		{
			// TODO: Implement this method
			switch(v.getTag().toString()){
				case "browser":

					startService(new Intent(getApplication(), FloatingBrowser.class));
					break;
				case "notes":

					break;
				case "message":

					break;

			}
		}


	}
}
