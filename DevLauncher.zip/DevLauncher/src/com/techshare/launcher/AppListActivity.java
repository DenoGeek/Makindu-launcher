package com.techshare.launcher;
import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.view.View;
import android.widget.*;
import java.util.*;
import android.view.View.*;

public class AppListActivity extends Activity {
private PackageManager manager;
private List<AppDetail> apps;
private ListView list;
	@Override
	protected void onCreate(Bundle
							savedInstanceState) {
		super.onCreate
		(savedInstanceState);
		setContentView(R.layout.apps);
loadApps();
loadListView();
	}


private void loadApps(){
manager = getPackageManager();
apps = new ArrayList<AppDetail>();
Intent i = new Intent(Intent.ACTION_MAIN,
null);
i.addCategory(Intent.CATEGORY_LAUNCHER)
;
List<ResolveInfo> availableActivities =
manager.queryIntentActivities(i, 0);
for(ResolveInfo ri:availableActivities){
AppDetail app = new AppDetail();
app.label = ri.loadLabel(manager);
app.name =
ri.activityInfo.packageName;
app.icon = ri.activityInfo.loadIcon
(manager);
apps.add(app);
}
	new CompareApps("g",apps,getApplicationContext());
}


private void loadListView(){
list = (ListView)findViewById(R.id.apps_list);
ArrayAdapter<AppDetail> adapter = new
ArrayAdapter<AppDetail>(this,
R.layout.list_item,
apps) {
@Override
public View getView(final int position,
View convertView, ViewGroup parent) {
	ImageView pp;
if(convertView == null){
convertView
= getLayoutInflater().inflate(R.layout.list_item, null);
}

ImageView appIcon =
(ImageView)convertView.findViewById(R.id.item_app_icon);

 pp =
(ImageView)convertView.findViewById(R.id.like);

appIcon.setImageDrawable(apps.get(position).icon);
TextView appLabel =
(TextView)convertView.findViewById(R.id.item_app_label);
appLabel.setText
(apps.get(position).label);
TextView appName =
(TextView)convertView.findViewById(R.id.item_app_name);
appName.setText
(apps.get(position).name);
String t=apps.get(position).name.toString();
	if(Sqlite.isFav(t,getApplicationContext())){
			pp.setImageResource(R.drawable.fav);
			
		}else{
			pp.setImageResource(R.drawable.addfav);
		}
		appIcon.setOnClickListener( new AppClick(t,getApplicationContext()));

		
pp.setOnClickListener(new OnClickListener(){
	@Override
	public void onClick(View v){
		String t=apps.get(position).name.toString();
		if(Sqlite.isFav(t,getApplicationContext())){
			Sqlite.delete(getApplicationContext(),t);
			notifyDataSetChanged();
		}else{
			
			Sqlite.insert(getApplicationContext(),t);
			notifyDataSetChanged();
		}
	}
});
return convertView;
}


};
list.setAdapter(adapter);
}


	
}



