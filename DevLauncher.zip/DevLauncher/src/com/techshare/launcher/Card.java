package com.techshare.launcher;

import android.widget.*;
import android.content.*;
import android.util.AttributeSet;
import android.graphics.Color;

public class Card extends RelativeLayout {
    private TextView header;
    private TextView description;
    private ImageView thumbnail;
    private ImageView icon;
	
    public Card(Context context) {
        super(context, null, R.attr.cardStyle);
        init();
    }
    public Card(Context context, AttributeSet attrs)
	{
        super(context, attrs, R.attr.cardStyle);
        init();
		
		}
		
	private void init() {
        inflate(getContext(), R.layout.card, this);
		setBackgroundColor(Color.parseColor("#ffffff"));
        //Add missing top level attributes
        int padding = 10;
        setPadding(padding, padding, padding,
				   padding);
        this.header = (TextView)findViewById
		(R.id.header);
        this.description = (TextView)findViewById
		(R.id.description);
        this.thumbnail = (ImageView)findViewById
		(R.id.thumbnail);
        this.icon = (ImageView)findViewById
		(R.id.icon);
    }
	
	
	
	}
		
