package com.techshare.launcher.fragments;

import android.app.Activity;
import android.os.*;
import android.view.*;
import android.database.*;
import android.database.sqlite.*;
import android.content.Context;
import java.util.*;
import android.widget.ArrayAdapter;
import android.widget.*;
import android.view.View.*;
import com.techshare.launcher.utils.ArrayUtils;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import com.techshare.launcher.Sqlite;
import com.techshare.launcher.R;
import com.techshare.launcher.Controler;
import java.io.*;
import com.techshare.launcher.views.ButtonWithIcons;
import android.graphics.Typeface;
import android.content.Intent;
import com.techshare.launcher.HomeActivity;
import android.preference.*;
public class ConfigureCustoms extends Fragment
{
	private View view;
	private ButtonWithIcons f,t,g,gi;
	public View onCreateView(LayoutInflater inflater ,
							 ViewGroup container ,
							 Bundle savedInstanceState ) {
		String strtext = getArguments().getString("web");
		String pid=strtext;

		view =inflater .inflate( R.layout .configure_customs,
								container, false);
		Typeface bloody = Typeface.createFromAsset(getActivity().getApplicationContext().getAssets(),"Bloodthirsty.ttf");	
		Typeface nice = Typeface.createFromAsset(getActivity().getApplicationContext().getAssets(),"fonts/Walkway_Bold.ttf");
		TextView y=(TextView)view.findViewById(R.id.configurecustomsTextView1);
		y.setTypeface(bloody);
		 g=(ButtonWithIcons)view.findViewById(R.id.fwd);
		
		g.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View v){
					//justFinalize();
					Intent h=new Intent(getActivity().getApplicationContext(),HomeActivity.class);
					h.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK);
					getActivity().startActivity(h);

				}
			});


		 gi=(ButtonWithIcons)view.findViewById(R.id.back);
		gi.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View v){
					//justFinalize();
					ConfigureDock webfrag = new ConfigureDock();
					Bundle bundle = new Bundle();
					bundle.putString("web", "web");
					webfrag.setArguments(bundle);
					FragmentTransaction ft = getActivity().getSupportFragmentManager()
						.beginTransaction();
					ft.setCustomAnimations(R.anim.slideleft,
										   R.anim.slideright);
					ft.replace(R.id.configure_appFrameLayout, webfrag,"fragment");
					// Start the animated transition.
					ft.commit();

				}
			});			
			
		if(strtext==null){
			RelativeLayout ghi=(RelativeLayout)view.findViewById(R.id.bottom);
			ghi.setVisibility(View.GONE);
		}
			configure();
								
				return view;				
		}
		
		
		public void configure(){
			
			f=(ButtonWithIcons)view.findViewById(R.id.updatedir);
			t=(ButtonWithIcons)view.findViewById(R.id.updatecol);
			
			f.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View v){
					EditText g=(EditText)view.findViewById(R.id.configure_customsEditText);
						File dir = new File
						(Environment.getExternalStorageDirectory
						 () + "/"+g.getText().toString());
						if(dir.exists() && dir.isDirectory()) {
							// do something here
							Controler.saveDir(g.getText().toString(),getActivity().getApplicationContext());
							Sqlite.report("Saved please Refresh launcher",getActivity().getApplicationContext());
							PreferenceManager.getDefaultSharedPreferences(getActivity())
								.edit().putString("refresh","Done").commit();
							
						}else{
							Sqlite.report("Erroneous directory",getActivity().getApplicationContext());
						}
				}
				
			});
			
			t.setOnClickListener(new OnClickListener(){
					@Override
					public void onClick(View v){
						EditText g=(EditText)view.findViewById(R.id.configure_customsEditText1);
                        
						if(Controler.isColor(g.getText().toString())){
							Controler.saveCol(g.getText().toString(),getActivity().getApplicationContext());
							Sqlite.report("Saved refresh launcher",getActivity().getApplicationContext());
							PreferenceManager.getDefaultSharedPreferences(getActivity())
								.edit().putString("refresh","Done").commit();
							
						}else{
							Sqlite.report("This is not a valid colour",getActivity().getApplicationContext());
						}
						
					}

				});
			
			
			}
			
			
			
}
