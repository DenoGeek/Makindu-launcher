package com.techshare.launcher.fragments;

import android.view.*;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.os.*;
import android.widget.*;
import android.graphics.Typeface;
import com.techshare.launcher.R;
import com.techshare.launcher.views.ButtonWithIcons;

import com.easyandroidanimations.library.PuffOutAnimation;
import com.easyandroidanimations.library.Animation;
import com.easyandroidanimations.library.AnimationListener;
import com.easyandroidanimations.library.BounceAnimation;
import com.easyandroidanimations.library.FlipVerticalAnimation;



public class IntroFragment extends Fragment
{
	private View view;
	private TextView y,x,z;
	private ImageView v;
	
	@Override
	public View onCreateView(LayoutInflater inflater ,
							 ViewGroup container ,
							 Bundle savedInstanceState ) {
		String strtext = getArguments().getString("web");
		String pid=strtext;

		view =inflater .inflate( R.layout .intro,
								container, false);
	
		Typeface bloody = Typeface.createFromAsset(getActivity().getApplicationContext().getAssets(),"Bloodthirsty.ttf");	
		Typeface nice = Typeface.createFromAsset(getActivity().getApplicationContext().getAssets(),"fonts/Walkway_Bold.ttf");
		y=(TextView)view.findViewById(R.id.introTextView1);
		
		v=(ImageView)view.findViewById(R.id.introImageView1);
		
		x=(TextView)view.findViewById(R.id.introTextView2);
		new BounceAnimation(y).setDuration(2300).animate();
		
		new Handler().postDelayed(new
			Runnable(){
				@Override
				public void run() {
		new PuffOutAnimation(v)
					.setListener(new AnimationListener(){
						@Override
						public void onAnimationEnd(Animation go){
							
							ConfigureHacks webfrag = new ConfigureHacks();
							Bundle bundle = new Bundle();
							bundle.putString("web", "web");
							webfrag.setArguments(bundle);
							FragmentTransaction ft = getActivity().getSupportFragmentManager()
								.beginTransaction();
							ft.setCustomAnimations(R.anim.slideleft,
												   R.anim.slideright);
							ft.replace(R.id.configure_appFrameLayout, webfrag,"fragment");
							// Start the animated transition.
							ft.commit();
							
							
						}
							}).
				animate();
			}
			},2000);
		x.setTypeface(nice);	
		y.setTypeface(bloody);	
								return view;
					
								}
	
	}
