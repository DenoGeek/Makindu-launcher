package com.techshare.launcher.views;

import android.widget.*;
import android.view.*;
import android.content.*;
import android.support.v4.graphics.drawable.*;
import com.techshare.launcher.R;
import android.graphics.*;
import java.io.*;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.graphics.Typeface;
import java.util.*;

import lecho.lib.hellocharts.listener.PieChartOnValueSelectListener;
import lecho.lib.hellocharts.model.PieChartData;
import lecho.lib.hellocharts.model.SliceValue;
import lecho.lib.hellocharts.util.ChartUtils;
import lecho.lib.hellocharts.view.Chart;
import lecho.lib.hellocharts.view.PieChartView;
import android.sax.*;


public class CpuView extends LinearLayout
{
	private PieChartView chart;
	private PieChartData data;
	private ViewGroup rootView;
	private boolean hasLabels = true;
	private boolean hasLabelsOutside = false;
	private boolean hasCenterCircle = false;
	private boolean hasCenterText1 = false;
	private boolean hasCenterText2 = false;
	private boolean isExploded = false;
	private boolean hasLabelForSelected = false;
	
	
	
	public CpuView(Context context){
		super(context);
		
		
		LayoutInflater inflater = (LayoutInflater) context
			.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		inflater.inflate(R.layout.pie_view, this, true);


		chart = (PieChartView)this.findViewById(R.id.chart);
		chart.setOnValueTouchListener(new ValueTouchListener());

		generateData();
		TextView title = (TextView)this.findViewById(R.id.pieviewTextView1);
		title.setText("Cpu processes");

		this.setBackgroundResource(R.drawable.glas);
		
	}
	
	private String executeTop() {
		java.lang.Process p = null;
		BufferedReader in = null;
		String returnString = null;
		try {
			p = Runtime.getRuntime().exec("top -n 1");
			in = new BufferedReader(new
									InputStreamReader(p.getInputStream()));
			while (returnString == null ||
				   returnString.contentEquals("")) {
				returnString = in.readLine();
			}
		} catch (IOException e) {
			//Log.e("executeTop", "error in getting first lineof top");
			e.printStackTrace();
		} finally {
			try {
				in.close();
				p.destroy();
			} catch (IOException e) {
				//Log.e("executeTop","error in closing and destroying topprocess");
				e.printStackTrace();
			}
		}
		return returnString;
	}
	
	private int[] getCpuUsageStatistic() {
		String tempString = executeTop();
		tempString = tempString.replaceAll(",", "");
		tempString = tempString.replaceAll("User", "");
		tempString = tempString.replaceAll("System", "")
			;
		tempString = tempString.replaceAll("IOW", "");
		tempString = tempString.replaceAll("IRQ", "");
		tempString = tempString.replaceAll("%", "");
		for (int i = 0; i < 10; i++) {
			tempString = tempString.replaceAll("  ", " ");
		}
		tempString = tempString.trim();
		String[] myString = tempString.split(" ");
		int[] cpuUsageAsInt = new int[myString.length];
		for (int i = 0; i < myString.length; i++) {
			myString[i] = myString[i].trim();
			cpuUsageAsInt[i] = Integer.parseInt(myString
												[i]);
		}
		return cpuUsageAsInt;
	}
	
	private void reset() {
		chart.setCircleFillRatio(1.0f);
		hasLabels = false;
		hasLabelsOutside = false;
		hasCenterCircle = false;
		hasCenterText1 = false;
		hasCenterText2 = false;
		isExploded = false;
		hasLabelForSelected = false;
	}

	private void generateData() {
		long dara[] =getUsedMemorySize();
		int mem=(int)dara[1]/1048576;
		String labeks[]={"Free","Total \n"+mem,"Used","Leak"};
		
		List<SliceValue> values = new ArrayList<SliceValue>();
		for (int i = 0; i < dara[i]; ++i) {
			SliceValue sliceValue = new SliceValue(dara[i], ChartUtils.pickColor());
			sliceValue.setLabel(labeks[i]);
			values.add(sliceValue);
		}

		data = new PieChartData(values);
		data.setHasLabels(hasLabels);
		data.setHasLabelsOnlyForSelected(hasLabelForSelected);
		data.setHasLabelsOutside(hasLabelsOutside);
		data.setHasCenterCircle(hasCenterCircle);

		if (isExploded) {
			data.setSlicesSpacing(24);
		}

		if (hasCenterText1) {
			data.setCenterText1("Storage");

			// Get roboto-italic font.
			Typeface tf = Typeface.createFromAsset(getContext().getAssets(), "Roboto-Italic.ttf");
			data.setCenterText1Typeface(tf);

			// Get font size from dimens.xml and convert it to sp(library uses sp values).
			data.setCenterText1FontSize(ChartUtils.px2sp(getResources().getDisplayMetrics().scaledDensity,
														 (int) getResources().getDimension(R.dimen.pie_chart_text1_size)));
		}

		if (hasCenterText2) {
			data.setCenterText2("Charts (Roboto Italic)");

			Typeface tf = Typeface.createFromAsset(getContext().getAssets(), "Roboto-Italic.ttf");

			data.setCenterText2Typeface(tf);
			data.setCenterText2FontSize(ChartUtils.px2sp(getResources().getDisplayMetrics().scaledDensity,
														 (int) getResources().getDimension(R.dimen.pie_chart_text2_size)));
		}

		chart.setPieChartData(data);
	}

	private void explodeChart() {
		isExploded = !isExploded;
		generateData();

	}
	
	
	public static long[] getUsedMemorySize() {
		long[] zote={0,0,0,0};
		long freeSize = 0L;
		long totalSize = 0L;
		long usedSize = -1L;
		try {
			Runtime info = Runtime.getRuntime();
			freeSize = info.freeMemory();
			totalSize = info.totalMemory();
			usedSize = totalSize - freeSize;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		zote[0]=freeSize;
		zote[1]=totalSize;
		zote[2]=usedSize;
		return zote;
	}
	

	private void toggleLabelsOutside() {
		// has labels have to be true:P
		hasLabelsOutside = !hasLabelsOutside;
		if (hasLabelsOutside) {
			hasLabels = true;
			hasLabelForSelected = false;
			chart.setValueSelectionEnabled(hasLabelForSelected);
		}

		if (hasLabelsOutside) {
			chart.setCircleFillRatio(0.7f);
		} else {
			chart.setCircleFillRatio(1.0f);
		}

		generateData();

	}

	private void toggleLabels() {
		hasLabels = !hasLabels;

		if (hasLabels) {
			hasLabelForSelected = false;
			chart.setValueSelectionEnabled(hasLabelForSelected);

			if (hasLabelsOutside) {
				chart.setCircleFillRatio(0.7f);
			} else {
				chart.setCircleFillRatio(1.0f);
			}
		}

		generateData();
	}

	private void toggleLabelForSelected() {
		hasLabelForSelected = !hasLabelForSelected;

		chart.setValueSelectionEnabled(hasLabelForSelected);

		if (hasLabelForSelected) {
			hasLabels = false;
			hasLabelsOutside = false;

			if (hasLabelsOutside) {
				chart.setCircleFillRatio(0.7f);
			} else {
				chart.setCircleFillRatio(1.0f);
			}
		}

		generateData();
	}

	/**
	 * To animate values you have to change targets values and then call {@link Chart#startDataAnimation()}
	 * method(don't confuse with View.animate()).
	 */
	private void prepareDataAnimation() {
		for (SliceValue value : data.getValues()) {
			value.setTarget((float) Math.random() * 30 + 15);
		}
	}

	private class ValueTouchListener implements PieChartOnValueSelectListener {

		@Override
		public void onValueSelected(int arcIndex, SliceValue value) {
			//Toast.makeText(getContext(), "Selected: " + value, Toast.LENGTH_SHORT).show();
		}

		@Override
		public void onValueDeselected() {
			// TODO Auto-generated method stub

		}

	}
    
	
	
}	
