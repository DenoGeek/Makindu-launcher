package com.techshare.launcher;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import android.net.*;
import android.preference.*;
import android.content.*;
import android.view.View.*;
import android.provider.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.database.*;
import android.database.sqlite.*;

public class MainActivity extends Activity
{
	
	private String imagename,img,action,mode;
	Bitmap bmp,b;
	File myImage;
	private EditText a,c;
	int sh,sw;
	ImageView iv;
	private final String dbName = "Android";
	//Table name
	private final String tableName = "Versions";
	//String array has list Android versions which will be populated in the list

	private SQLiteDatabase sampleDB = null;
    /** Called when the activity is first created. */
	private ImageView buttonLoadImage;

	private static int RESULT_LOAD_IMAGE = 1;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.set_owner);
		
		buttonLoadImage = (ImageView) findViewById
		(R.id.pic);
		a= (EditText) findViewById(R.id.edit1);
        c=(EditText)findViewById(R.id.edit2);
		
        buttonLoadImage.setOnClickListener(new
			View.OnClickListener() {
				@Override
				public void onClick(View
									arg0) {
					Intent i = new
						Intent(
						Intent.ACTION_PICK,
						android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
					startActivityForResult(i, RESULT_LOAD_IMAGE);
				}
			});
	}
	
	public void save(View v){
		String name=a.getText().toString();
		String h=c.getText().toString();
		PreferenceManager.getDefaultSharedPreferences(getBaseContext())
			.edit().putString("user", name).commit();
		PreferenceManager.getDefaultSharedPreferences(getBaseContext())
			.edit().putString("phone", h).commit();
		
			this.finish();
	}


	public void quit(View v){
		this.finish();
	}
	@Override
	protected void onActivityResult(int requestCode, int
									resultCode, Intent data) {
		super.onActivityResult(requestCode,
							   resultCode, data);
		if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && null != data) {
			Uri selectedImage =
				data.getData();
			String[] filePathColumn =
			{ MediaStore.Images.Media.DATA };
			Cursor cursor =
				getContentResolver().query(selectedImage,
										   filePathColumn, null, null, null);
			cursor.moveToFirst();
			int columnIndex =
				cursor.getColumnIndex(filePathColumn[0]);
			String picturePath =
				cursor.getString(columnIndex);
			cursor.close();
			ImageView imageView =
				(ImageView) findViewById(R.id.pic);
			imageView.setImageBitmap(BitmapFactory.decodeFile
									 (picturePath));
		}
	}
	

	
	

}
