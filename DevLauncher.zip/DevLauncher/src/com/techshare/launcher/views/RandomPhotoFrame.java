package com.techshare.launcher.views;

import android.widget.*;
import android.content.Context;
import android.view.*;
import java.io.File;
import android.os.Environment;
import java.io.FilenameFilter;
import java.util.Random;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import com.techshare.launcher.R;
import com.easyandroidanimations.library.ScaleInAnimation;
import android.graphics.Color;
import android.app.WallpaperManager;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import com.techshare.launcher.Sqlite;
import com.techshare.launcher.Controler;
import com.techshare.launcher.utils.*;
public class RandomPhotoFrame extends FrameLayout
{
	
	private ImageView im,bt,ov;
	private TextView h;
	public RandomPhotoFrame(Context c){
		super(c);
		FrameLayout.LayoutParams photopars=new FrameLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT,LinearLayout.LayoutParams.FILL_PARENT);
		FrameLayout.LayoutParams impars=new FrameLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT,LinearLayout.LayoutParams.FILL_PARENT);
		FrameLayout.LayoutParams btpars=new FrameLayout.LayoutParams(70,70);
		FrameLayout.LayoutParams textpars=new FrameLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,70);
		textpars.gravity=Gravity.RIGHT | Gravity. BOTTOM;
		textpars.setMargins(4,4,4,4);
		
		
		btpars.gravity=Gravity.TOP;
		btpars.setMargins(4,4,4,4);
		
		impars.gravity=Gravity.TOP;
		impars.setMargins(6,6,4,4);
		im=new ImageView(c);
		im.setLayoutParams(impars);
		ov=new ImageView(c);
		ov.setLayoutParams(photopars);
		ov.setBackgroundResource(R.drawable.frame);
	
		bt=new ImageView(c);
		bt.setLayoutParams(btpars);
		bt.setImageResource(R.drawable.update);
		 bt.setOnClickListener(new OnClickListener(){
			 @Override
			 public void onClick(View v){
				 if(externalMemoryAvailable()){
				 configa();}else{
					 im.setBackgroundResource(R.drawable.user);
				 }
			 }
		 });
		 
		 h=new TextView (c);
		 h.setLayoutParams(textpars);
		 h.setTextColor(Color.WHITE);
		 
		 configa();
		 
		this.addView(im);
		this.addView(ov);
		this.addView(bt);
		this.addView(h);
	}
	
	private void configa(){
		
		
		final WallpaperManager wallpaperManager =
			WallpaperManager.getInstance(getContext());
		
		final Drawable wallpaperDrawable = wallpaperManager.getDrawable();
		
		
		File rootDir;
		if(Controler.loadDir(getContext())!=null){
			 rootDir = new File
			(Environment.getExternalStorageDirectory
			 ().getPath() + "/"+Controler.loadDir(getContext()));
			h.setText(Controler.loadDir(getContext()));
		}else{
			 rootDir = new File
			(Environment.getExternalStorageDirectory
			 ().getPath() + "/Download/");
			 h.setText("Downloads");
		}
		if(rootDir.exists() && rootDir.isDirectory()) {
			
		File files[] = rootDir.listFiles(new
			FilenameFilter() {
				@Override
				public boolean accept(File dir, String name) {
					return name.toLowerCase().endsWith
					(".jpg");
				}
			});
		if(files.length<1){
			Bitmap g=ImageUtils.cropToSquare(ImageUtils.drawableToBitmap(wallpaperDrawable));
			im.setImageBitmap(g);
				//Sqlite.report("No pics in this directory",getContext());
		}else{
		File image = files[new Random().nextInt
		(files.length)];
		
		Bitmap myBitmap = BitmapFactory.decodeFile
		(image.getAbsolutePath());
		if(myBitmap!=null){
		Bitmap cropped=cropToSquare(myBitmap);
		BitmapDrawable ob = new
			BitmapDrawable(getResources(), cropped);
		im.setBackgroundDrawable(ob);
			new ScaleInAnimation(im)
				.setDuration(500)
				.animate();
		
		}else{
			configa();
		}
		}
		
		}else{
			Bitmap g=ImageUtils.cropToSquare(ImageUtils.drawableToBitmap(wallpaperDrawable));
			im.setImageBitmap(g);
			Sqlite.report("Erroneous directory",getContext());
		}
		
	}
	
	public  boolean externalMemoryAvailable() {
        return android.os.Environment.
			getExternalStorageState().equals(
			android.os.Environment.MEDIA_MOUNTED);
    }
	
	
	
	public static Bitmap cropToSquare(Bitmap bitmap){
		int width  = bitmap.getWidth();
		int height = bitmap.getHeight();
		int newWidth = (height > width) ? width : height;
		int newHeight = (height > width)? height - ( height - width) : height;
		int cropW = (width - height) / 2;
		cropW = (cropW < 0)? 0: cropW;
		int cropH = (height - width) / 2;
		cropH = (cropH < 0)? 0: cropH;
		Bitmap cropImg = Bitmap.createBitmap
		(bitmap, cropW, cropH, newWidth, newHeight);
		return cropImg;
	}
}

