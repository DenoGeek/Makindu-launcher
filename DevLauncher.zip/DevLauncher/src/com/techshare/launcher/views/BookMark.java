package com.techshare.launcher.views;

import android.graphics.drawable.Drawable;
public class BookMark
{
	 String title;
	 String link;
	 Drawable icon;
}
