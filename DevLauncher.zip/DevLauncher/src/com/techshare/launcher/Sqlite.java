package com.techshare.launcher;
import android.widget.*;
import android.view.View.*;
import android.database.*;
import android.database.sqlite.*;
import android.content.*;
import android.preference.*;
import java.io.*;
import java.util.*;
import android.view.WindowManager;
public class Sqlite
{
	
	public static void initDatabase(Context c){
		
		String dbName = "makindu";
		String tableName = "appslist";
		String tableViews="views";
		String tableApps="apps";
		String tableDock="dock";
		String tableNews="news";
		SQLiteDatabase myDb = null;
		try{
			myDb=  c.openOrCreateDatabase(dbName, c.MODE_WORLD_WRITEABLE, null);
            //create tables
			myDb.execSQL("CREATE TABLE IF NOT EXISTS " + tableName +	" (id INTEGER PRIMARY KEY,package VARCHAR,state VARCHAR);");
			myDb.execSQL("CREATE TABLE IF NOT EXISTS " + tableViews +	" (id INTEGER PRIMARY KEY,tag VARCHAR,xcor VARCHAR,ycor VARCHAR,state VARCHAR);");
			myDb.execSQL("CREATE TABLE IF NOT EXISTS " + tableApps +	" (id INTEGER PRIMARY KEY,name VARCHAR,pname VARCHAR,xcor VARCHAR,ycor VARCHAR,screen VARCHAR);");
			myDb.execSQL("CREATE TABLE IF NOT EXISTS " + tableDock +	" (id INTEGER PRIMARY KEY,name VARCHAR);");
			myDb.execSQL("CREATE TABLE IF NOT EXISTS " + tableNews +	" (id INTEGER PRIMARY KEY,image VARCHAR,news VARCHAR,likes VARCHAR,link VARCHAR);");
		}catch (SQLiteException se ) {
			Sqlite.report("Error creating databases",c);
		} finally {
			//report("sucess creating database",c);
			//myDb.execSQL("DELETE FROM " + tableName);

        	if (myDb != null) {
				
				//sampleDB.execSQL("DELETE FROM " + tableName);
        		//sampleDB.close();
        	}
		}
		
		
		
		
	}
	
	public static void InsertBasics(Context c){
		//insert base views
		if(Controler.isIntroduced(c)){

		}else{
			insertView(c,"selfdestruct");
			insertView(c,"scareface");
			insertView(c,"calllog");
			insertView(c,"prompt");
			insertView(c,"cpuview");
			insertView(c,"pielib");
			insertView(c,"photo");
			insertView(c,"dock");


			insertNews(c,"1.jpg","Welcome to makindu Launcher let us know about your user experience","689","http://techshare.co.ke");
			PreferenceManager.getDefaultSharedPreferences(c)
				.edit().putString("check","done").commit();

		}
		
	}
	
	
	public static boolean isFav(String app,Context c){

		String dbName = "makindu";
		String tableName = "appslist";
		SQLiteDatabase myDb = null;
		
		
	    String f=new String();
f=null;
		//check whether ths array exists in database
		try {
			
			
        	//Instantiate sampleDB object
        	myDb =  c.openOrCreateDatabase(dbName, c.MODE_WORLD_WRITEABLE, null);
        	//Create Cursor object to read versions from the table
        	Cursor a = myDb.rawQuery("SELECT * FROM "+tableName+" WHERE package='"+app+"'", null);
        	//If Cursor is valid
        	if (a != null ) {
        		//Move cursor to first row
        		if  (a.moveToFirst()) {
					do {
							//Get version from Cursor
							f = a.getString(a.getColumnIndex("package"));
					

						}while (a.moveToNext()); //Move to next row
					} 
        	}
			
       	 } catch (SQLiteException se ) {
			//Server.newload(c);
        } finally {
        	if (myDb== null) {
				//sampleDB.execSQL("DELETE FROM " + tableName);
			//sampleDB.close();
        	}
        }
		
		//if it doesnt exis load it onlinr
		
		
		//if it is loade
	
		if(f==null){
			return false;
		}else{
			return true;
		}
	
	
	}
	
	
	
	public static void report(String err,Context context){
		Toast.makeText(context,err, Toast.LENGTH_LONG).show();
		}
		
	
	public static void insert(Context c,String app){
		
		String dbName = "makindu";
		String tableName = "appslist";
		SQLiteDatabase myDb = null;
		String state="1";
		try{
			myDb=  c.openOrCreateDatabase(dbName, c.MODE_WORLD_WRITEABLE, null);
			myDb.execSQL("INSERT INTO " + tableName + "(package,state) Values ('"+app+"','"+state+"' )");
		}catch (SQLiteException se ) {
			Sqlite.report("Error saving category restarting loader",c);

		} finally {
			
			PreferenceManager.getDefaultSharedPreferences(c)
				.edit().putString("refresh","Done").commit();
			
		}	
	}
	
	
	public static void delete(Context c,String app){
		String dbName = "makindu";
		String tableName = "appslist";
		SQLiteDatabase myDb = null;
		String state="1";
		try{
			myDb=  c.openOrCreateDatabase(dbName, c.MODE_WORLD_WRITEABLE, null);
			myDb.execSQL( "DELETE FROM " + tableName + " WHERE package='"+app+"'" ); 	
			//report("Removed from favs",c);
        	
		}catch (SQLiteException se ) {
			Sqlite.report("Error removing from favs",c);

		} finally {
			PreferenceManager.getDefaultSharedPreferences(c)
				.edit().putString("refresh","Done").commit();
			
      if (myDb == null) {

		  //sampleDB.execSQL("DELETE FROM " + tableName);
        		//sampleDB.close();
        	}
		}
		
		
	}
	
	
	
	
	//These are the vimodas that handle the hack views
	
	//function to insert a view
	
	public static void insertView(Context c,String view){

		String dbName = "makindu";
		String tableName = "views";
		int xcor,ycor;
		SQLiteDatabase myDb = null;
		WindowManager windowManager = (WindowManager)
			c
			.getSystemService(Context.WINDOW_SERVICE);

		int width=windowManager.getDefaultDisplay()
			.getWidth()-200;
		int height=windowManager.getDefaultDisplay()
			.getHeight()-200;
		
		if(view.equals("dock")){
			xcor=0;
		 ycor=0;
		}else{
		 xcor=new Random().nextInt(width);
		 ycor=new Random().nextInt(height);}
		String state="0";
		try{
			myDb=  c.openOrCreateDatabase(dbName, c.MODE_WORLD_WRITEABLE, null);
			myDb.execSQL("INSERT INTO " + tableName + "(tag,xcor,ycor,state) Values ('"+view+"','"+xcor+"','"+ycor+"','"+state+"')");
		}catch (SQLiteException se ) {
			Sqlite.report("Error saving view try again",c);

		} finally {
			PreferenceManager.getDefaultSharedPreferences(c)
				.edit().putString("refresh","Done").commit();
		}	
	}
	
	
	public static int inTise(String s){

		int a=1;

		try
		{
			// the String to int conversion happens here
			a = Integer.parseInt(s.trim());
// print out the value after the conversion
			System.out.println("int i = " + a);
		}
		catch (NumberFormatException nfe)
		{
			System.out.println("NumberFormatException: " + nfe.getMessage());
		}
		return a;

	}
	
	

	//function to insert a view

	public static void insertApp(Context c,String name,String pname,int screen){

		WindowManager windowManager = (WindowManager)
			c
			.getSystemService(Context.WINDOW_SERVICE);

		int width=windowManager.getDefaultDisplay()
			.getWidth()-200;
		int height=windowManager.getDefaultDisplay()
			.getHeight()-200;
		
		String dbName = "makindu";
		String tableName = "apps";
		SQLiteDatabase myDb = null;
		int xcor=new Random().nextInt(width);
		int ycor=new Random().nextInt(height);
		try{
			myDb=  c.openOrCreateDatabase(dbName, c.MODE_WORLD_WRITEABLE, null);
			myDb.execSQL("INSERT INTO " + tableName + "(name,pname,xcor,ycor,screen) Values ('"+name+"','"+pname+"','"+xcor+"','"+ycor+"','"+screen+"')");
		}catch (SQLiteException se ) {
			Sqlite.report("Error saving view try again",c);

		} finally {
			PreferenceManager.getDefaultSharedPreferences(c)
				.edit().putString("refresh","Done").commit();
			
		}	
	}
	
	
	public static String[] ViewCors(Context cc,String tag){
		String[] data={"0","0","hello"};
		String dbName = "makindu";
		String tableViews="views";
		SQLiteDatabase myDb = null;
		
		try{
			myDb =  cc.openOrCreateDatabase(dbName,Context. MODE_PRIVATE, null);

			Cursor c = myDb.rawQuery("SELECT * FROM "+tableViews+" WHERE tag ='"+tag+"' ORDER BY id desc", null);
        	//If Cursor is valid
        	if (c != null ) {
        		//Move cursor to first row
        		if  (c.moveToFirst()) {
        			do {
        				//Get version from Cursor
        				String t = c.getString(c.getColumnIndex("tag"));
						String xcor = c.getString(c.getColumnIndex("xcor"));
						String ycor= c.getString(c.getColumnIndex("ycor"));
						data[0]=t;
						data[1]=xcor;
						data[2]=ycor;
						
					}while (c.moveToNext()); //Move to next row
        		} 
        	}

		}catch (SQLiteException se ) {
			Sqlite.report("Couldnt Load views data",cc);
		} finally {

		}
		
		return data;
	}
	
	
	public static void updateScreen(final Context c,String tag,int xcor,int ycor,int screen){
		String dbName = "makindu";
		String tableViews="apps";
		SQLiteDatabase myDb = null;
		try{
			myDb =  c.openOrCreateDatabase(dbName, Context.MODE_PRIVATE, null);

			myDb.execSQL( "UPDATE " + tableViews + " SET xcor = '"+xcor+"' WHERE name='"+tag+"'" ); 		
			myDb.execSQL( "UPDATE " + tableViews + " SET ycor = '"+ycor+"' WHERE name='"+tag+"'" ); 		
			myDb.execSQL( "UPDATE " + tableViews + " SET screen = '"+screen+"' WHERE name='"+tag+"'" );
		}catch (SQLiteException se ) {
        	Toast.makeText(c, "Couldn't update into databasedatabase", Toast.LENGTH_LONG).show();
        } finally {
			
        	if (myDb != null) {
				//Sqlite.report("updated",c);
			}
		}

	}
	
	
	
	public static boolean isHome(String app,Context c){

		String dbName = "makindu";
		String tableName = "apps";
		SQLiteDatabase myDb = null;


	    String f=new String();
		f=null;
		//check whether ths array exists in database
		try {


        	//Instantiate sampleDB object
        	myDb =  c.openOrCreateDatabase(dbName, c.MODE_WORLD_WRITEABLE, null);
        	//Create Cursor object to read versions from the table
        	Cursor a = myDb.rawQuery("SELECT * FROM "+tableName+" WHERE pname='"+app+"'", null);
        	//If Cursor is valid
        	if (a != null ) {
        		//Move cursor to first row
        		if  (a.moveToFirst()) {
					do {
						//Get version from Cursor
						f = a.getString(a.getColumnIndex("pname"));


					}while (a.moveToNext()); //Move to next row
				} 
        	}
		} catch (SQLiteException se ) {
			//Server.newload(c);
        } finally {
        	if (myDb== null) {
				//sampleDB.execSQL("DELETE FROM " + tableName);
				//sampleDB.close();
        	}
        }

		//if it doesnt exis load it onlinr


		//if it is loade

		if(f==null){
			return false;
		}else{
			return true;
		}


	}
	
	
	
	//=======================this function now deletes an app from the hom} screen========
	public static void deleteApp(Context c,String app){
		String dbName = "makindu";
		String tableName = "apps";
		SQLiteDatabase myDb = null;
		String state="1";
		try{
			myDb=  c.openOrCreateDatabase(dbName, c.MODE_WORLD_WRITEABLE, null);
			myDb.execSQL( "DELETE FROM " + tableName + " WHERE pname='"+app+"'" ); 	
			//report("Removed from favs",c);

		}catch (SQLiteException se ) {
			Sqlite.report("Error removing from favs",c);

		} finally {
			PreferenceManager.getDefaultSharedPreferences(c)
				.edit().putString("refresh","Done").commit();
			
			if (myDb == null) {


        		//sampleDB.execSQL("DELETE FROM " + tableName);
        		//sampleDB.close();
        	}
		}


	}
	
	
	//functiom to insert to dock

	public static void insertDock(Context c,String name){

		String dbName = "makindu";
		String tableName = "dock";
		SQLiteDatabase myDb = null;
		
		try{
			myDb=  c.openOrCreateDatabase(dbName, c.MODE_WORLD_WRITEABLE, null);
			myDb.execSQL("INSERT INTO " + tableName + "(name) Values ('"+name+"')");
			//Sqlite.report("Inserted ",c);
		}catch (SQLiteException se ) {
			Sqlite.report("Error saving dock try again",c);

		} finally {
			PreferenceManager.getDefaultSharedPreferences(c)
				.edit().putString("refresh","Done").commit();
			
		}	
	}
	
	public static boolean isDockFull(Context c){

		String dbName = "makindu";
		String tableName = "dock";
		SQLiteDatabase myDb = null;

		int counter=0;
	    String f=new String();
		f=null;
		//check whether ths array exists in database
		try {


        	//Instantiate sampleDB object
        	myDb =  c.openOrCreateDatabase(dbName, c.MODE_WORLD_WRITEABLE, null);
        	//Create Cursor object to read versions from the table
        	Cursor a = myDb.rawQuery("SELECT * FROM "+tableName, null);
        	//If Cursor is valid
        	if (a != null ) {
        		//Move cursor to first row
        		if  (a.moveToFirst()) {
					do {
						//Get version from Cursor
						f = a.getString(a.getColumnIndex("name"));

						if(f.equals("")){}else{counter++;}
					}while (a.moveToNext()); //Move to next row
				} 
        	}
		} catch (SQLiteException se ) {
			//Server.newload(c);
        } finally {
        	if (myDb== null) {
				//sampleDB.execSQL("DELETE FROM " + tableName);
				//sampleDB.close();
        	}
        }

		//if it doesnt exis load it onlinr


		//if it is loade

		if(counter<5){
			return false;
		}else{
			return true;
		}


	}
	
	//---------FUNCTION TO DELETE AN APP FROM DOCK BAR
	public static void deleteDock(Context c,String app){
		String dbName = "makindu";
		String tableName = "dock";
		SQLiteDatabase myDb = null;
		String state="1";
		try{
			myDb=  c.openOrCreateDatabase(dbName, c.MODE_WORLD_WRITEABLE, null);
			myDb.execSQL( "DELETE FROM " + tableName + " WHERE name='"+app+"'" ); 	
			//report("Removed from dock",c);

		}catch (SQLiteException se ) {
			Sqlite.report("Error removing from dock",c);

		} finally {
			PreferenceManager.getDefaultSharedPreferences(c)
				.edit().putString("refresh","Done").commit();
			
			if (myDb == null) {


        		//sampleDB.execSQL("DELETE FROM " + tableName);
        		//sampleDB.close();
        	}
		}


	}
	
	
	//checks whether an app is in dock
	
	public static boolean isDock(String app,Context c){

		String dbName = "makindu";
		String tableName = "dock";
		SQLiteDatabase myDb = null;


	    String f=new String();
		f=null;
		//check whether ths array exists in database
		try {


        	//Instantiate sampleDB object
        	myDb =  c.openOrCreateDatabase(dbName, c.MODE_WORLD_WRITEABLE, null);
        	//Create Cursor object to read versions from the table
        	Cursor a = myDb.rawQuery("SELECT * FROM "+tableName+" WHERE name='"+app+"'", null);
        	//If Cursor is valid
        	if (a != null ) {
        		//Move cursor to first row
        		if  (a.moveToFirst()) {
					do {
						//Get version from Cursor
						f = a.getString(a.getColumnIndex("name"));


					}while (a.moveToNext()); //Move to next row
				} 
        	}
		} catch (SQLiteException se ) {
			//Server.newload(c);
        } finally {
        	if (myDb== null) {
				//sampleDB.execSQL("DELETE FROM " + tableName);
				//sampleDB.close();
        	}
        }

		//if it doesnt exis load it onlinr


		//if it is loade

		if(f==null){
			return false;
		}else{
			return true;
		}


	}
	
	
	
	
	public static void insertNews(Context c,String image,String news,String likes,String link){

		String dbName = "makindu";
		String tableName = "news";
		SQLiteDatabase myDb = null;
		String state="1";
		try{
			myDb=  c.openOrCreateDatabase(dbName, c.MODE_WORLD_WRITEABLE, null);
			myDb.execSQL("INSERT INTO " + tableName + "(image,news,likes,link) Values ('"+image+"','"+news+"','"+likes+"','"+link+"' )");
		}catch (SQLiteException se ) {
			//Sqlite.report("Error saving news restarting loader",c);

		} finally {

			PreferenceManager.getDefaultSharedPreferences(c)
				.edit().putString("refresh","Done").commit();

		}	
	}
	
}
